export type StreamPlatform = 'youtube' | 'facebook' | 'twitch' | 'kick' | 'custom';

export interface StreamTarget {
  id: string;
  platform: StreamPlatform;
  label: string;
  serverUrl: string;
  streamKey: string;
  enabled: boolean;
}

export interface VideoItem {
  id: string;
  title: string;
  url: string;
  duration: number; // in seconds
  thumbnail?: string;
  category: 'music' | 'gaming' | 'nature' | 'news' | 'spiritual' | 'custom';
  resolution?: string;
}

export interface OverlayConfig {
  showWatermark: boolean;
  watermarkText: string;
  showTicker: boolean;
  tickerText: string;
  showClock: boolean;
  clockTimezone: string;
  showViewers: boolean;
  viewerBase: number;
  showSlate: boolean;
  slateText: string;
  audioVolume: number; // 0 to 100
  isMuted: boolean;
}

export type StreamStatus = 'idle' | 'starting' | 'live' | 'paused' | 'error';

export interface StreamSession {
  id: string;
  name: string;
  description: string;
  status: StreamStatus;
  loopMode: 'infinite_247' | 'single' | 'scheduled';
  targets: StreamTarget[];
  playlist: VideoItem[];
  currentVideoIndex: number;
  currentVideoTime: number;
  overlays: OverlayConfig;
  startedAt: number | null;
  uptimeSeconds: number;
  fps: number;
  bitrateKbps: number;
  droppedFrames: number;
  totalBytesSentMb: number;
  loopCycle: number;
  serverCpuPercent: number;
  serverMemMb: number;
  isSlateActive: boolean;
  logs: { timestamp: string; message: string; type: 'info' | 'success' | 'warn' | 'error' }[];
  errorMessage?: string;
}

export interface ServerStats {
  uptimeSeconds: number;
  cpuPercent: number;
  memoryUsedMb: number;
  memoryTotalMb: number;
  activeStreamsCount: number;
  totalStreamsCount: number;
  totalBandwidthKbps: number;
  daemonStatus: 'running' | 'degraded';
}
