import React from 'react';
import { Activity, Clock, Cpu, HardDrive, RefreshCw, Server, Wifi } from 'lucide-react';
import { StreamSession } from '../types/stream';
import { Language, translations } from '../utils/i18n';

interface TelemetryBarProps {
  session: StreamSession;
  lang: Language;
}

export const TelemetryBar: React.FC<TelemetryBarProps> = ({ session, lang }) => {
  const t = translations[lang];
  const isLive = session.status === 'live';

  const formatUptime = (seconds: number) => {
    if (!seconds || seconds <= 0) return '00:00:00';
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;

    if (d > 0) {
      return `${d}d ${h.toString().padStart(2, '0')}h ${m.toString().padStart(2, '0')}m`;
    }
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs font-mono">
      {/* 1. Live Uptime */}
      <div className="bg-neutral-900/90 border border-neutral-800/80 rounded-md p-2.5 flex flex-col justify-between">
        <div className="flex items-center justify-between text-neutral-400 text-[11px] mb-1">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-rose-400" />
            {t.streamUptime}
          </span>
          {isLive && <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />}
        </div>
        <div className="text-base font-bold text-white tabular-nums">
          {formatUptime(session.uptimeSeconds)}
        </div>
        <div className="text-[10px] text-neutral-500 mt-0.5">
          {isLive ? 'Non-stop 24/7' : 'Offline'}
        </div>
      </div>

      {/* 2. Video Bitrate */}
      <div className="bg-neutral-900/90 border border-neutral-800/80 rounded-md p-2.5 flex flex-col justify-between">
        <div className="flex items-center justify-between text-neutral-400 text-[11px] mb-1">
          <span className="flex items-center gap-1">
            <Wifi className="w-3 h-3 text-emerald-400" />
            {t.streamBitrate}
          </span>
          <span className="text-[10px] text-emerald-400 font-semibold">CBR</span>
        </div>
        <div className="text-base font-bold text-white tabular-nums">
          {isLive ? `${session.bitrateKbps.toLocaleString()} kbps` : '0 kbps'}
        </div>
        <div className="text-[10px] text-neutral-500 mt-0.5">
          {isLive ? 'Optimal for 1080p' : 'Pipeline Standby'}
        </div>
      </div>

      {/* 3. Output FPS */}
      <div className="bg-neutral-900/90 border border-neutral-800/80 rounded-md p-2.5 flex flex-col justify-between">
        <div className="flex items-center justify-between text-neutral-400 text-[11px] mb-1">
          <span className="flex items-center gap-1">
            <Activity className="w-3 h-3 text-sky-400" />
            {t.streamFps}
          </span>
        </div>
        <div className="text-base font-bold text-white tabular-nums">
          {isLive ? `${session.fps}.0 FPS` : '0.0 FPS'}
        </div>
        <div className="text-[10px] text-neutral-500 mt-0.5">
          Dropped: {session.droppedFrames} (0.0%)
        </div>
      </div>

      {/* 4. Loop Cycle */}
      <div className="bg-neutral-900/90 border border-neutral-800/80 rounded-md p-2.5 flex flex-col justify-between">
        <div className="flex items-center justify-between text-neutral-400 text-[11px] mb-1">
          <span className="flex items-center gap-1">
            <RefreshCw className="w-3 h-3 text-amber-400" />
            {t.streamLoops}
          </span>
          <span className="text-[10px] text-amber-400">24/7 Loop</span>
        </div>
        <div className="text-base font-bold text-white tabular-nums">
          Cycle #{session.loopCycle}
        </div>
        <div className="text-[10px] text-neutral-500 mt-0.5">
          Auto-repeating
        </div>
      </div>

      {/* 5. Total Bandwidth Sent */}
      <div className="bg-neutral-900/90 border border-neutral-800/80 rounded-md p-2.5 flex flex-col justify-between">
        <div className="flex items-center justify-between text-neutral-400 text-[11px] mb-1">
          <span className="flex items-center gap-1">
            <HardDrive className="w-3 h-3 text-indigo-400" />
            {t.streamSent}
          </span>
        </div>
        <div className="text-base font-bold text-white tabular-nums">
          {session.totalBytesSentMb > 1024
            ? `${(session.totalBytesSentMb / 1024).toFixed(2)} GB`
            : `${Math.round(session.totalBytesSentMb)} MB`}
        </div>
        <div className="text-[10px] text-neutral-500 mt-0.5">
          Unlimited egress
        </div>
      </div>

      {/* 6. Server Health */}
      <div className="bg-neutral-900/90 border border-neutral-800/80 rounded-md p-2.5 flex flex-col justify-between">
        <div className="flex items-center justify-between text-neutral-400 text-[11px] mb-1">
          <span className="flex items-center gap-1">
            <Cpu className="w-3 h-3 text-teal-400" />
            {t.serverCpu}
          </span>
          <span className="text-[10px] text-teal-400">RAM: {session.serverMemMb}MB</span>
        </div>
        <div className="text-base font-bold text-white tabular-nums">
          {session.serverCpuPercent}%
        </div>
        <div className="text-[10px] text-emerald-400 mt-0.5 flex items-center gap-1">
          <Server className="w-2.5 h-2.5" />
          <span>Server Daemon OK</span>
        </div>
      </div>
    </div>
  );
};
