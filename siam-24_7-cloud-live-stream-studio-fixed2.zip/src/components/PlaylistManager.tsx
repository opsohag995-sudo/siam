import React, { useState, useRef } from 'react';
import {
  Film,
  Plus,
  Play,
  Trash2,
  ArrowUp,
  ArrowDown,
  RefreshCw,
  Upload,
  Link,
  Sparkles,
  CheckCircle2,
  FileVideo,
  AlertCircle
} from 'lucide-react';
import { StreamSession, VideoItem } from '../types/stream';
import { DEFAULT_VIDEOS } from '../data/defaultMedia';
import { Language, translations } from '../utils/i18n';

interface PlaylistManagerProps {
  session: StreamSession;
  lang: Language;
  onUpdatePlaylist: (playlist: VideoItem[]) => void;
  onSelectVideo: (index: number) => void;
  onUpdateLoopMode: (mode: 'infinite_247' | 'single') => void;
}

export const PlaylistManager: React.FC<PlaylistManagerProps> = ({
  session,
  lang,
  onUpdatePlaylist,
  onSelectVideo,
  onUpdateLoopMode,
}) => {
  const t = translations[lang];
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newUrl, setNewUrl] = useState('');
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);

  // Direct local video file picker and server upload handler
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadStatus(lang === 'bn' ? 'ভিডিও সার্ভারে আপলোড হচ্ছে... অনুগ্রহ করে অপেক্ষা করুন' : 'Uploading video to server... please wait');

    try {
      const formData = new FormData();
      formData.append('video', file);

      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!res.ok) {
        throw new Error('Upload failed');
      }

      const data = await res.json();
      if (data.success && data.playlist) {
        onUpdatePlaylist(data.playlist);
        setUploadStatus(lang === 'bn' ? '✅ ভিডিও সফলভাবে আপলোড হয়েছে এবং লাইভ শুরু হয়েছে!' : '✅ Uploaded & broadcasting!');
        setTimeout(() => setUploadStatus(null), 3500);
      }
    } catch (err: any) {
      console.error('File upload error:', err);
      setUploadStatus(lang === 'bn' ? '⚠️ আপলোড ব্যর্থ হয়েছে, আবার চেষ্টা করুন' : '⚠️ Upload failed, please retry');
      setTimeout(() => setUploadStatus(null), 4000);
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleAddUrlVideo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUrl.trim() || !newTitle.trim()) return;

    const newVideo: VideoItem = {
      id: `vid-${Date.now()}`,
      title: newTitle.trim(),
      url: newUrl.trim(),
      duration: 300,
      category: 'custom',
      resolution: '1080p',
    };

    onUpdatePlaylist([...session.playlist, newVideo]);
    setNewTitle('');
    setNewUrl('');
    setShowAddModal(false);
  };

  const handleAddPreset = (preset: VideoItem) => {
    const copy = { ...preset, id: `vid-${Date.now()}` };
    onUpdatePlaylist([...session.playlist, copy]);
  };

  const handleRemove = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (session.playlist.length <= 1) {
      alert(lang === 'bn' ? 'প্লেলিস্টে অন্তত একটি ভিডিও থাকতে হবে।' : 'Playlist must have at least one video.');
      return;
    }
    const updated = session.playlist.filter(v => v.id !== id);
    onUpdatePlaylist(updated);
  };

  const handleMove = (index: number, direction: 'up' | 'down', e: React.MouseEvent) => {
    e.stopPropagation();
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === session.playlist.length - 1) return;

    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    const newItems = [...session.playlist];
    const [moved] = newItems.splice(index, 1);
    newItems.splice(targetIndex, 0, moved);
    onUpdatePlaylist(newItems);
  };

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/mp4,video/webm,video/ogg,video/quicktime,video/*"
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <h2 className="text-base font-semibold text-white flex items-center gap-2">
            <Film className="w-4 h-4 text-rose-500" />
            <span>{t.playlistTitle}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            {lang === 'bn'
              ? 'আপনার নিজের ভিডিও ফাইল আপলোড করুন অথবা নিচের তৈরি ভিডিওগুলো ব্যবহার করে ২৪/৭ লুপে চালান'
              : t.playlistDesc}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Loop Mode Selector */}
          <div className="flex items-center bg-neutral-900 border border-neutral-800 rounded p-0.5 text-xs font-medium">
            <button
              onClick={() => onUpdateLoopMode('infinite_247')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-colors ${
                session.loopMode === 'infinite_247'
                  ? 'bg-rose-600 text-white font-semibold'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <RefreshCw className="w-3 h-3" />
              <span>{t.loopInfinite}</span>
            </button>
            <button
              onClick={() => onUpdateLoopMode('single')}
              className={`px-2.5 py-1 rounded transition-colors ${
                session.loopMode === 'single'
                  ? 'bg-neutral-800 text-white font-semibold'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              {t.loopSingle}
            </button>
          </div>

          {/* Upload Video Button */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded text-xs font-semibold transition-colors shadow-sm"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'ভিডিও আপলোড' : 'Upload'}</span>
          </button>

          <button
            onClick={() => setShowAddModal(!showAddModal)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded text-xs font-medium transition-colors border border-neutral-700"
          >
            <Link className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'লিংক' : 'Link'}</span>
          </button>
        </div>
      </div>

      {/* Upload progress message */}
      {uploadStatus && (
        <div className="p-3 bg-neutral-900 border border-rose-500/50 rounded text-xs text-rose-300 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
          <span>{uploadStatus}</span>
        </div>
      )}

      {/* Add Video by URL Box */}
      {showAddModal && (
        <form onSubmit={handleAddUrlVideo} className="p-4 bg-neutral-900 border border-neutral-700 rounded-lg space-y-3">
          <div className="text-xs font-semibold text-white uppercase tracking-wider font-mono">
            {lang === 'bn' ? 'অনলাইন ভিডিও লিংক যোগ করুন' : 'Add Direct Video Stream Link'}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">
                {t.videoTitle}
              </label>
              <input
                type="text"
                placeholder="My Stream Video 24/7"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                required
                className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-xs text-white focus:outline-none focus:border-rose-500 font-mono"
              />
            </div>
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">
                {t.videoUrl}
              </label>
              <input
                type="url"
                placeholder="https://example.com/video.mp4"
                value={newUrl}
                onChange={(e) => setNewUrl(e.target.value)}
                required
                className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-xs text-white focus:outline-none focus:border-rose-500 font-mono"
              />
            </div>
          </div>
          <div className="flex justify-between items-center pt-2">
            <span className="text-[11px] text-neutral-500">
              * Supports direct MP4, MKV, WebM or HLS .m3u8 CDN links
            </span>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-3 py-1 bg-neutral-800 text-neutral-400 hover:text-white rounded text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-xs font-semibold"
              >
                {t.addVideoBtn}
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Preset Quick Add suggestions */}
      <div className="bg-neutral-900/60 border border-neutral-800/80 rounded-lg p-3.5">
        <div className="text-[11px] font-semibold text-neutral-300 mb-2 flex items-center gap-1.5 font-mono">
          <Sparkles className="w-3.5 h-3.5 text-rose-400" />
          <span>{lang === 'bn' ? 'কপিরাইট-ফ্রি রেডিমেড ভিডিও (ক্লিক করলেই যুক্ত হবে):' : 'Ready-to-stream copyright-free presets:'}</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {DEFAULT_VIDEOS.map((preset) => (
            <button
              key={preset.id}
              onClick={() => handleAddPreset(preset)}
              className="text-xs px-2.5 py-1 rounded bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-3 h-3 text-rose-400" />
              <span className="truncate max-w-[200px]">{preset.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Playlist Items */}
      <div className="space-y-2.5">
        <div className="text-xs font-semibold text-neutral-400 font-mono flex items-center justify-between">
          <span>{lang === 'bn' ? `প্লেলিস্টে মোট ${session.playlist.length}টি ভিডিও আছে` : `Playlist Queue (${session.playlist.length} videos)`}</span>
          <span className="text-[11px] text-neutral-500 hidden sm:inline">
            {lang === 'bn' ? 'যেকোনো ভিডিওতে ক্লিক করে তাৎক্ষণিক লাইভে সুইচ করুন' : 'Click any track to switch live feed'}
          </span>
        </div>

        {session.playlist.map((video, index) => {
          const isCurrentlyPlaying = index === session.currentVideoIndex;

          return (
            <div
              key={video.id}
              onClick={() => onSelectVideo(index)}
              className={`p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                isCurrentlyPlaying
                  ? 'bg-rose-950/20 border-rose-600/70 shadow-md ring-1 ring-rose-500/20'
                  : 'bg-neutral-900/70 border-neutral-800/80 hover:bg-neutral-900'
              }`}
            >
              {/* Left Column: Number + Title + Metadata */}
              <div className="flex items-start sm:items-center gap-3 min-w-0">
                {/* Index / Playing icon */}
                <div className="w-8 h-8 rounded-lg bg-neutral-950 border border-neutral-800 flex items-center justify-center shrink-0 mt-0.5 sm:mt-0">
                  {isCurrentlyPlaying ? (
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                  ) : (
                    <span className="font-mono text-xs text-neutral-400 font-semibold">{index + 1}</span>
                  )}
                </div>

                {/* Video Info Stack */}
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <h3 className="text-xs font-bold text-white leading-tight">
                      {video.title}
                    </h3>
                    {isCurrentlyPlaying && (
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-rose-600 text-white shrink-0">
                        NOW STREAMING
                      </span>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-neutral-400 font-mono">
                    <span className="text-neutral-300 font-semibold">{formatSeconds(video.duration)}</span>
                    <span>·</span>
                    <span className="text-neutral-400">{video.resolution || '1080p'}</span>
                    <span>·</span>
                    <span className="text-neutral-500 truncate max-w-[180px] sm:max-w-xs">
                      {video.url.startsWith('/media/') ? 'Local Server Asset' : video.url.startsWith('blob:') ? 'Device File' : video.url}
                    </span>
                  </div>
                </div>
              </div>

              {/* Right Column: Controls Buttons Row */}
              <div
                className="flex items-center justify-between sm:justify-end gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-neutral-800/60"
                onClick={(e) => e.stopPropagation()}
              >
                <button
                  onClick={() => onSelectVideo(index)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-colors ${
                    isCurrentlyPlaying
                      ? 'bg-rose-600/30 text-rose-300 border border-rose-500/40 font-semibold'
                      : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
                  }`}
                  title="Switch Live Feed to This Video"
                >
                  {isCurrentlyPlaying ? 'Live' : 'Play Now'}
                </button>

                <div className="flex items-center gap-1">
                  <button
                    onClick={(e) => handleMove(index, 'up', e)}
                    disabled={index === 0}
                    className="p-1.5 text-neutral-400 hover:text-white disabled:opacity-20 transition-colors rounded hover:bg-neutral-800"
                    title="Move Up"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={(e) => handleMove(index, 'down', e)}
                    disabled={index === session.playlist.length - 1}
                    className="p-1.5 text-neutral-400 hover:text-white disabled:opacity-20 transition-colors rounded hover:bg-neutral-800"
                    title="Move Down"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={(e) => handleRemove(video.id, e)}
                    className="p-1.5 text-neutral-400 hover:text-rose-400 transition-colors rounded hover:bg-neutral-800"
                    title="Remove from Playlist"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
