import React, { useState } from 'react';
import {
  Terminal,
  Copy,
  Check,
  Download,
  Server,
  Code,
  ShieldCheck,
  Cpu,
  Layers,
  CheckCircle2,
  HardDrive
} from 'lucide-react';
import { StreamSession } from '../types/stream';
import { Language, translations } from '../utils/i18n';

interface ServerArchitectureProps {
  session: StreamSession;
  lang: Language;
}

export const ServerArchitecture: React.FC<ServerArchitectureProps> = ({ session, lang }) => {
  const t = translations[lang];
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const activeTarget = session.targets.find(t => t.enabled && t.streamKey) || session.targets[0] || {
    serverUrl: 'rtmp://a.rtmp.youtube.com/live2',
    streamKey: 'YOUR_STREAM_KEY'
  };

  const primaryVideo = session.playlist[0] || { url: 'https://example.com/stream-input.mp4' };
  const rtmpTargetUrl = `${activeTarget.serverUrl.replace(/\/$/, '')}/${activeTarget.streamKey || 'SECRET_KEY'}`;

  // Real production-ready FFmpeg command
  const ffmpegCommand = `ffmpeg -re -stream_loop -1 -i "${primaryVideo.url}" \\
  -vf "drawtext=text='${session.overlays.watermarkText}':x=w-tw-40:y=40:fontsize=28:fontcolor=white:box=1:boxcolor=black@0.5:boxborderw=8" \\
  -c:v libx264 -preset veryfast -b:v 4500k -maxrate 4500k -bufsize 9000k \\
  -pix_fmt yuv420p -g 60 -keyint_min 60 \\
  -c:a aac -b:a 160k -ar 44100 \\
  -f flv "${rtmpTargetUrl}"`;

  const dockerCommand = `docker run -d \\
  --name siam-247-stream \\
  --restart=always \\
  -e RTMP_INGEST="${rtmpTargetUrl}" \\
  -e STREAM_BITRATE="4500k" \\
  siam/cloud-streamer:latest`;

  const systemdService = `[Unit]
Description=Siam 24/7 Background Live Stream Daemon
After=network.target

[Service]
Type=simple
User=root
Restart=always
RestartSec=5
ExecStart=/usr/bin/ffmpeg -re -stream_loop -1 -i "${primaryVideo.url}" -c:v libx264 -preset veryfast -b:v 4500k -maxrate 4500k -bufsize 9000k -pix_fmt yuv420p -g 60 -c:a aac -b:a 160k -ar 44100 -f flv "${rtmpTargetUrl}"

[Install]
WantedBy=multi-user.target`;

  const handleCopy = (text: string, sectionId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionId);
    setTimeout(() => setCopiedSection(null), 2500);
  };

  const handleDownloadScript = () => {
    const scriptContent = `#!/bin/bash
# ==========================================
# SIAM 24/7 AUTOMATED LIVE STREAM DAEMON
# Website: Siam Cloud Studio
# ==========================================

echo "Starting Siam 24/7 RTMP Stream Pipeline..."

while true; do
  ${ffmpegCommand}
  echo "Stream interrupted. Auto-reconnecting in 3 seconds..."
  sleep 3
done
`;
    const blob = new Blob([scriptContent], { type: 'text/x-sh' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'siam-247-stream-runner.sh';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-neutral-800">
        <div>
          <h2 className="text-base font-semibold text-white flex items-center gap-2">
            <Server className="w-4 h-4 text-rose-500" />
            <span>{t.ffmpegScriptTitle}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            {lang === 'bn'
              ? 'সার্ভার সাইড ব্যাকগ্রাউন্ড প্রসেসিং আর্কিটেকচার ও স্বয়ংক্রিয় কমান্ড'
              : 'Server-side background processing architecture & automated streaming scripts'}
          </p>
        </div>

        <button
          onClick={handleDownloadScript}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded text-xs font-medium transition-colors border border-neutral-700"
        >
          <Download className="w-3.5 h-3.5" />
          <span>{t.downloadBash}</span>
        </button>
      </div>

      {/* Architecture Visual Diagram */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4">
        <div className="text-xs font-semibold text-white uppercase tracking-wider font-mono mb-3">
          {lang === 'bn' ? 'সিস্টেম আর্কিটেকচার ফ্লো' : 'System Architecture Pipeline'}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs font-mono">
          <div className="bg-neutral-950 p-3 rounded border border-neutral-800 flex flex-col justify-between">
            <span className="text-neutral-400 text-[11px]">1. Media Source</span>
            <div className="font-bold text-white my-1">Video Playlist</div>
            <div className="text-[10px] text-neutral-500">MP4 / Cloud Storage Loop</div>
          </div>
          <div className="bg-neutral-950 p-3 rounded border border-rose-900/50 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-rose-400 text-[11px]">2. Siam Daemon</span>
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
            </div>
            <div className="font-bold text-white my-1">Server Background Worker</div>
            <div className="text-[10px] text-rose-400/80">Runs 24/7 Even If Offline</div>
          </div>
          <div className="bg-neutral-950 p-3 rounded border border-neutral-800 flex flex-col justify-between">
            <span className="text-neutral-400 text-[11px]">3. Transcoder</span>
            <div className="font-bold text-white my-1">FFmpeg x264 CBR</div>
            <div className="text-[10px] text-neutral-500">4500kbps 60fps AAC Audio</div>
          </div>
          <div className="bg-neutral-950 p-3 rounded border border-emerald-900/50 flex flex-col justify-between">
            <span className="text-emerald-400 text-[11px]">4. Live Relays</span>
            <div className="font-bold text-white my-1">RTMP Ingest</div>
            <div className="text-[10px] text-emerald-400">YouTube, Facebook, Twitch</div>
          </div>
        </div>
      </div>

      {/* Live Server Terminal Logs */}
      <div className="bg-neutral-950 border border-neutral-800 rounded-lg overflow-hidden font-mono text-xs">
        <div className="bg-neutral-900/90 px-4 py-2 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal className="w-3.5 h-3.5 text-neutral-400" />
            <span className="text-xs font-semibold text-neutral-300">
              {lang === 'bn' ? 'সার্ভার লাইভ ইভেন্ট লগ (Live Daemon Output)' : 'Server Live Event Logs'}
            </span>
          </div>
          <span className="text-[10px] text-neutral-500">
            {session.status === 'live' ? 'Streaming Active' : 'Standby'}
          </span>
        </div>

        <div className="p-3.5 max-h-52 overflow-y-auto space-y-1.5 text-[11px] leading-relaxed">
          {session.logs && session.logs.length > 0 ? (
            session.logs.map((log, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className="text-neutral-600 shrink-0 select-none">[{log.timestamp}]</span>
                <span
                  className={
                    log.type === 'success'
                      ? 'text-emerald-400'
                      : log.type === 'warn'
                      ? 'text-amber-400'
                      : log.type === 'error'
                      ? 'text-rose-400'
                      : 'text-neutral-300'
                  }
                >
                  {log.message}
                </span>
              </div>
            ))
          ) : (
            <div className="text-neutral-600">No logs yet. Daemon idle.</div>
          )}
        </div>
      </div>

      {/* FFmpeg Command Code Block */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-white text-xs">
            <Code className="w-4 h-4 text-rose-400" />
            <span>FFmpeg 24/7 RTMP Streaming Command</span>
          </div>
          <button
            onClick={() => handleCopy(ffmpegCommand, 'ffmpeg')}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded text-xs transition-colors"
          >
            {copiedSection === 'ffmpeg' ? (
              <>
                <Check className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-400">{t.copied}</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3" />
                <span>{t.copyCommand}</span>
              </>
            )}
          </button>
        </div>

        <pre className="p-3 bg-neutral-950 border border-neutral-800 rounded font-mono text-xs text-neutral-300 overflow-x-auto whitespace-pre leading-relaxed">
          {ffmpegCommand}
        </pre>
      </div>

      {/* Self-hosting instructions (Docker & Systemd) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
        {/* Docker Command */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-white">Docker 24/7 Deployment</span>
            <button
              onClick={() => handleCopy(dockerCommand, 'docker')}
              className="text-neutral-400 hover:text-white flex items-center gap-1 text-[11px]"
            >
              <Copy className="w-3 h-3" />
              <span>{copiedSection === 'docker' ? t.copied : 'Copy'}</span>
            </button>
          </div>
          <pre className="p-2.5 bg-neutral-950 border border-neutral-800 rounded text-neutral-400 text-[11px] overflow-x-auto whitespace-pre">
            {dockerCommand}
          </pre>
        </div>

        {/* Systemd Service */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-white">Linux Systemd Service</span>
            <button
              onClick={() => handleCopy(systemdService, 'systemd')}
              className="text-neutral-400 hover:text-white flex items-center gap-1 text-[11px]"
            >
              <Copy className="w-3 h-3" />
              <span>{copiedSection === 'systemd' ? t.copied : 'Copy'}</span>
            </button>
          </div>
          <pre className="p-2.5 bg-neutral-950 border border-neutral-800 rounded text-neutral-400 text-[11px] overflow-x-auto whitespace-pre max-h-36">
            {systemdService}
          </pre>
        </div>
      </div>
    </div>
  );
};
