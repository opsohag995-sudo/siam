import React, { useState, useRef } from 'react';
import {
  ShieldAlert,
  Play,
  Square,
  RefreshCw,
  Upload,
  Plus,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Server,
  Layers,
  Radio,
  Sliders,
  Terminal,
  Lock,
  Eye,
  EyeOff,
  Video,
  Clock,
  Sparkles,
  Volume2,
  VolumeX,
  Zap,
  Activity,
  Check,
  Film
} from 'lucide-react';
import { StreamSession, StreamTarget, VideoItem, OverlayConfig } from '../types/stream';
import { Language } from '../utils/i18n';

interface AdminPanelProps {
  session: StreamSession;
  lang: Language;
  onStartStream: () => void;
  onStopStream: () => void;
  onUpdateTargets: (targets: StreamTarget[]) => void;
  onUpdatePlaylist: (playlist: VideoItem[]) => void;
  onSelectVideo: (index: number) => void;
  onUpdateLoopMode: (mode: 'infinite_247' | 'single') => void;
  onUpdateOverlays: (overlays: Partial<OverlayConfig>) => void;
  onToggleSlate: () => void;
  onLockAdmin: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  session,
  lang,
  onStartStream,
  onStopStream,
  onUpdateTargets,
  onUpdatePlaylist,
  onSelectVideo,
  onUpdateLoopMode,
  onUpdateOverlays,
  onToggleSlate,
  onLockAdmin,
}) => {
  const [activeAdminSubTab, setActiveAdminSubTab] = useState<'broadcast' | 'targets' | 'playlist' | 'overlays' | 'terminal'>('broadcast');
  const [showKeyMap, setShowKeyMap] = useState<Record<string, boolean>>({});
  const [isRestarting, setIsRestarting] = useState(false);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  // Targets local state
  const [localTargets, setLocalTargets] = useState<StreamTarget[]>(session.targets);
  const [savingTargets, setSavingTargets] = useState(false);

  // Overlays local state
  const [localOverlays, setLocalOverlays] = useState<OverlayConfig>(session.overlays);
  const [savingOverlays, setSavingOverlays] = useState(false);

  // Video upload state
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // New URL modal/input
  const [newVideoUrl, setNewVideoUrl] = useState('');
  const [newVideoTitle, setNewVideoTitle] = useState('');

  const isLive = session.status === 'live';

  const triggerNotice = (msg: string) => {
    setActionNotice(msg);
    setTimeout(() => setActionNotice(null), 3500);
  };

  // Emergency FFmpeg restart
  const handleEmergencyRestart = async () => {
    setIsRestarting(true);
    try {
      const res = await fetch('/api/stream/restart', { method: 'POST' });
      if (res.ok) {
        triggerNotice(lang === 'bn' ? '✅ ব্রডকাস্ট ইঞ্জিন সফলভাবে রিস্টার্ট হয়েছে!' : '✅ Stream pipeline restarted successfully!');
      }
    } catch (err) {
      console.error(err);
      triggerNotice(lang === 'bn' ? '⚠️ রিস্টার্ট কমান্ড পাঠানো হয়েছে' : '⚠️ Restart signal dispatched');
    } finally {
      setIsRestarting(false);
    }
  };

  // Clear server logs
  const handleClearLogs = async () => {
    try {
      await fetch('/api/stream/clear-logs', { method: 'POST' });
      triggerNotice(lang === 'bn' ? '🧹 সব লগ সফলভাবে মুছে ফেলা হয়েছে' : '🧹 Logs cleared successfully');
    } catch (err) {
      console.error(err);
    }
  };

  // Save RTMP Targets
  const handleSaveTargets = () => {
    setSavingTargets(true);
    onUpdateTargets(localTargets);
    setTimeout(() => {
      setSavingTargets(false);
      triggerNotice(lang === 'bn' ? '✅ আরটিএমপি সেটিংস সংরক্ষিত হয়েছে!' : '✅ RTMP settings saved & active!');
    }, 400);
  };

  // Save Overlays
  const handleSaveOverlays = () => {
    setSavingOverlays(true);
    onUpdateOverlays(localOverlays);
    setTimeout(() => {
      setSavingOverlays(false);
      triggerNotice(lang === 'bn' ? '✅ অন-স্ক্রিন গ্রাফিক্স আপডেট করা হয়েছে!' : '✅ Overlays updated successfully!');
    }, 400);
  };

  // Handle direct file upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadStatus(lang === 'bn' ? 'ভিডিও আপলোড ও সার্ভারে প্রসেস হচ্ছে...' : 'Uploading & processing video...');

    try {
      const formData = new FormData();
      formData.append('video', file);

      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!res.ok) throw new Error('Upload failed');
      const data = await res.json();
      if (data.success && data.playlist) {
        onUpdatePlaylist(data.playlist);
        setUploadStatus(lang === 'bn' ? '✅ ভিডিও সফলভাবে আপলোড হয়েছে এবং লাইভে যুক্ত করা হয়েছে!' : '✅ Video uploaded & live feed updated!');
        setTimeout(() => setUploadStatus(null), 3500);
      }
    } catch (err) {
      setUploadStatus(lang === 'bn' ? '⚠️ আপলোড ব্যর্থ হয়েছে' : '⚠️ Upload failed');
      setTimeout(() => setUploadStatus(null), 3500);
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Add video via URL
  const handleAddVideoUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVideoUrl.trim()) return;

    const newVideo: VideoItem = {
      id: `vid-admin-${Date.now()}`,
      title: newVideoTitle.trim() || 'Online Video Stream',
      url: newVideoUrl.trim(),
      duration: 300,
      category: 'custom',
      resolution: '1080p',
    };

    onUpdatePlaylist([newVideo, ...session.playlist]);
    setNewVideoUrl('');
    setNewVideoTitle('');
    triggerNotice(lang === 'bn' ? '✅ নতুন ভিডিও প্লেলিস্টে যোগ করা হয়েছে' : '✅ Video added to queue');
  };

  // Delete video
  const handleDeleteVideo = (id: string) => {
    if (session.playlist.length <= 1) {
      triggerNotice(lang === 'bn' ? '⚠️ প্লেলিস্টে অন্তত একটি ভিডিও থাকতে হবে' : '⚠️ Must keep at least one video');
      return;
    }
    const updated = session.playlist.filter(v => v.id !== id);
    onUpdatePlaylist(updated);
    triggerNotice(lang === 'bn' ? '🗑️ ভিডিও মুছে ফেলা হয়েছে' : '🗑️ Video removed');
  };

  return (
    <div className="space-y-6">
      {/* Action Notification Toast */}
      {actionNotice && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 py-3 px-5 rounded-xl bg-neutral-900 border border-emerald-500/50 text-emerald-400 font-mono text-xs shadow-2xl animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* Admin Master Top Banner */}
      <div className="bg-gradient-to-r from-neutral-900 via-neutral-900 to-rose-950/40 border border-neutral-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white font-mono tracking-tight">
                  {lang === 'bn' ? 'অ্যাডমিন মাস্টার কন্ট্রোল সেন্টার' : 'Admin Master Control Center'}
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  SUPER ADMIN
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                {lang === 'bn'
                  ? 'সার্ভার ইঞ্জিন, ইউটিউব আরটিএমপি, ভিডিও সুইচিং ও অন-স্ক্রিন ব্র্যান্ডিং নিয়ন্ত্রণ করুন'
                  : 'Manage FFmpeg daemon, RTMP stream keys, live video switcher, and on-screen overlays'}
              </p>
            </div>
          </div>
        </div>

        {/* Top Emergency Actions */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Emergency Restart Pipeline */}
          <button
            onClick={handleEmergencyRestart}
            disabled={isRestarting}
            className="flex-1 md:flex-initial flex items-center justify-center gap-2 py-2 px-3.5 bg-neutral-800 hover:bg-neutral-700 text-amber-300 border border-amber-500/30 rounded-lg text-xs font-semibold font-mono transition-all active:scale-95 disabled:opacity-50"
            title="Force re-spawns FFmpeg pipeline if YouTube stream disconnects"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRestarting ? 'animate-spin' : ''}`} />
            <span>{lang === 'bn' ? 'ইঞ্জিন রিস্টার্ট' : 'Restart Engine'}</span>
          </button>

          {/* Master Live Toggle */}
          {isLive ? (
            <button
              onClick={onStopStream}
              className="flex-1 md:flex-initial flex items-center justify-center gap-2 py-2 px-4 bg-neutral-950 hover:bg-neutral-800 text-rose-400 border border-rose-900/80 rounded-lg text-xs font-bold uppercase tracking-wider transition-all"
            >
              <Square className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
              <span>{lang === 'bn' ? 'লাইভ বন্ধ করুন' : 'Stop Live'}</span>
            </button>
          ) : (
            <button
              onClick={onStartStream}
              className="flex-1 md:flex-initial flex items-center justify-center gap-2 py-2 px-4 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-all shadow-md shadow-rose-950/60"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{lang === 'bn' ? 'লাইভ শুরু করুন' : 'Start Live 24/7'}</span>
            </button>
          )}

          {/* Lock Admin */}
          <button
            onClick={onLockAdmin}
            className="flex items-center justify-center gap-1.5 py-2 px-3 bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white border border-neutral-700 rounded-lg text-xs font-medium transition-colors"
            title="Lock Admin Session"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'লক করুন' : 'Lock'}</span>
          </button>
        </div>
      </div>

      {/* Admin Navigation Sub-Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto pb-1 border-b border-neutral-800 text-xs font-medium">
        <button
          onClick={() => setActiveAdminSubTab('broadcast')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-t-lg transition-colors whitespace-nowrap border-b-2 ${
            activeAdminSubTab === 'broadcast'
              ? 'border-rose-500 text-white bg-neutral-900/90 font-bold'
              : 'border-transparent text-neutral-400 hover:text-white hover:bg-neutral-900/50'
          }`}
        >
          <Radio className="w-4 h-4 text-rose-500" />
          <span>{lang === 'bn' ? '১. ব্রডকাস্ট ও ইঞ্জিন' : '1. Broadcast & Daemon'}</span>
        </button>

        <button
          onClick={() => setActiveAdminSubTab('targets')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-t-lg transition-colors whitespace-nowrap border-b-2 ${
            activeAdminSubTab === 'targets'
              ? 'border-rose-500 text-white bg-neutral-900/90 font-bold'
              : 'border-transparent text-neutral-400 hover:text-white hover:bg-neutral-900/50'
          }`}
        >
          <Server className="w-4 h-4 text-emerald-400" />
          <span>{lang === 'bn' ? '২. ইউটিউব ও আরটিএমপি' : '2. YouTube & RTMP Keys'}</span>
        </button>

        <button
          onClick={() => setActiveAdminSubTab('playlist')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-t-lg transition-colors whitespace-nowrap border-b-2 ${
            activeAdminSubTab === 'playlist'
              ? 'border-rose-500 text-white bg-neutral-900/90 font-bold'
              : 'border-transparent text-neutral-400 hover:text-white hover:bg-neutral-900/50'
          }`}
        >
          <Film className="w-4 h-4 text-sky-400" />
          <span>{lang === 'bn' ? '৩. ভিডিও সুইচিং ও আপলোড' : '3. Video Switcher & Upload'}</span>
        </button>

        <button
          onClick={() => setActiveAdminSubTab('overlays')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-t-lg transition-colors whitespace-nowrap border-b-2 ${
            activeAdminSubTab === 'overlays'
              ? 'border-rose-500 text-white bg-neutral-900/90 font-bold'
              : 'border-transparent text-neutral-400 hover:text-white hover:bg-neutral-900/50'
          }`}
        >
          <Layers className="w-4 h-4 text-amber-400" />
          <span>{lang === 'bn' ? '৪. অন-স্ক্রিন গ্রাফিক্স' : '4. Overlays & Ticker'}</span>
        </button>

        <button
          onClick={() => setActiveAdminSubTab('terminal')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-t-lg transition-colors whitespace-nowrap border-b-2 ${
            activeAdminSubTab === 'terminal'
              ? 'border-rose-500 text-white bg-neutral-900/90 font-bold'
              : 'border-transparent text-neutral-400 hover:text-white hover:bg-neutral-900/50'
          }`}
        >
          <Terminal className="w-4 h-4 text-purple-400" />
          <span>{lang === 'bn' ? '৫. এফএফএমপ্যাগ কনসোল' : '5. FFmpeg Live Logs'}</span>
        </button>
      </div>

      {/* SUB-TAB 1: BROADCAST & ENGINE */}
      {activeAdminSubTab === 'broadcast' && (
        <div className="space-y-6">
          {/* Quick Status Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1">
              <div className="text-[11px] font-mono text-neutral-500 uppercase">{lang === 'bn' ? 'ব্রডকাস্ট স্ট্যাটাস' : 'Broadcast Status'}</div>
              <div className="flex items-center gap-2">
                <span className={`w-2.5 h-2.5 rounded-full ${isLive ? 'bg-rose-500 animate-ping' : 'bg-neutral-600'}`} />
                <span className={`text-sm font-bold font-mono ${isLive ? 'text-rose-400' : 'text-neutral-400'}`}>
                  {isLive ? 'LIVE 24/7' : 'STANDBY'}
                </span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1">
              <div className="text-[11px] font-mono text-neutral-500 uppercase">{lang === 'bn' ? 'লুপ মোড' : 'Loop Engine'}</div>
              <div className="text-sm font-bold font-mono text-white flex items-center gap-1.5">
                <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
                <span>{session.loopMode === 'infinite_247' ? '24/7 Infinite' : 'Single Play'}</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1">
              <div className="text-[11px] font-mono text-neutral-500 uppercase">{lang === 'bn' ? 'ইমার্জেন্সি স্লেট' : 'Emergency Slate'}</div>
              <div className="text-sm font-bold font-mono text-white flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${session.isSlateActive ? 'bg-amber-400' : 'bg-neutral-600'}`} />
                <span>{session.isSlateActive ? 'Active (BRB)' : 'Normal Feed'}</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1">
              <div className="text-[11px] font-mono text-neutral-500 uppercase">{lang === 'bn' ? 'সার্ভার সিপিইউ' : 'Server Load'}</div>
              <div className="text-sm font-bold font-mono text-emerald-400 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5" />
                <span>{session.serverCpuPercent}% / {session.serverMemMb} MB</span>
              </div>
            </div>
          </div>

          {/* Engine Controls Box */}
          <div className="p-5 rounded-xl bg-neutral-900 border border-neutral-800 space-y-4">
            <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>{lang === 'bn' ? 'মাস্টার সার্ভার অপারেশন' : 'Master Server Operations'}</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Loop mode toggle */}
              <div className="p-3.5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="text-xs font-semibold text-neutral-300">
                  {lang === 'bn' ? '২৪/৭ অটোমেটিক লুপ মোড' : '24/7 Infinite Loop Mode'}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => onUpdateLoopMode('infinite_247')}
                    className={`flex-1 py-1.5 px-2 rounded text-xs font-mono font-medium transition-colors ${
                      session.loopMode === 'infinite_247'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    ২৪/৭ অবিরাম
                  </button>
                  <button
                    onClick={() => onUpdateLoopMode('single')}
                    className={`flex-1 py-1.5 px-2 rounded text-xs font-mono font-medium transition-colors ${
                      session.loopMode === 'single'
                        ? 'bg-rose-600 text-white'
                        : 'bg-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    একবার
                  </button>
                </div>
              </div>

              {/* Emergency Slate Toggle */}
              <div className="p-3.5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="text-xs font-semibold text-neutral-300">
                  {lang === 'bn' ? 'ইমার্জেন্সি স্লেট (Be Right Back)' : 'Emergency Slate Screen'}
                </div>
                <button
                  onClick={onToggleSlate}
                  className={`w-full py-2 px-3 rounded text-xs font-mono font-semibold transition-colors flex items-center justify-center gap-1.5 ${
                    session.isSlateActive
                      ? 'bg-amber-500 hover:bg-amber-400 text-neutral-950'
                      : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>{session.isSlateActive ? 'স্লেট বন্ধ করুন (স্বাভাবিক ফিড)' : 'স্লেট অন করুন (বিরতি)'}</span>
                </button>
              </div>

              {/* Force Restart */}
              <div className="p-3.5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="text-xs font-semibold text-neutral-300">
                  {lang === 'bn' ? 'এফএফএমপ্যাগ ইঞ্জিন রি-স্পন' : 'Re-spawn FFmpeg Engine'}
                </div>
                <button
                  onClick={handleEmergencyRestart}
                  disabled={isRestarting}
                  className="w-full py-2 px-3 bg-neutral-800 hover:bg-neutral-700 text-sky-400 border border-neutral-700 rounded text-xs font-mono font-semibold transition-colors flex items-center justify-center gap-1.5 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isRestarting ? 'animate-spin' : ''}`} />
                  <span>ইমার্জেন্সি রিস্টার্ট</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: YOUTUBE & RTMP TARGETS */}
      {activeAdminSubTab === 'targets' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
              <Server className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'bn' ? 'ইউটিউব ও অন্যান্য আরটিএমপি সেটিংস' : 'YouTube & RTMP Streaming Targets'}</span>
            </h3>
            <button
              onClick={handleSaveTargets}
              disabled={savingTargets}
              className="py-1.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold font-mono transition-all flex items-center gap-1.5 shadow"
            >
              <Check className="w-3.5 h-3.5" />
              <span>{savingTargets ? 'সংরক্ষণ হচ্ছে...' : 'সংরক্ষণ ও প্রয়োগ করুন'}</span>
            </button>
          </div>

          <div className="space-y-4">
            {localTargets.map((target, idx) => (
              <div
                key={target.id}
                className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-3"
              >
                <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
                  <div className="flex items-center gap-2.5">
                    <span
                      className={`w-2.5 h-2.5 rounded-full ${
                        target.enabled && isLive ? 'bg-rose-500 animate-ping' : target.enabled ? 'bg-emerald-500' : 'bg-neutral-600'
                      }`}
                    />
                    <span className="text-sm font-bold text-white font-mono">{target.label}</span>
                  </div>

                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono">
                    <span className="text-neutral-400">{target.enabled ? 'সক্রিয় (Active)' : 'নিষ্ক্রিয় (Disabled)'}</span>
                    <input
                      type="checkbox"
                      checked={target.enabled}
                      onChange={e => {
                        const updated = [...localTargets];
                        updated[idx].enabled = e.target.checked;
                        setLocalTargets(updated);
                      }}
                      className="w-4 h-4 accent-rose-500 rounded"
                    />
                  </label>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-mono text-neutral-400">
                      {lang === 'bn' ? 'সার্ভার আরটিএমপি ইউআরএল (Server Ingest URL):' : 'Server Ingest URL:'}
                    </label>
                    <input
                      type="text"
                      value={target.serverUrl}
                      onChange={e => {
                        const updated = [...localTargets];
                        updated[idx].serverUrl = e.target.value;
                        setLocalTargets(updated);
                      }}
                      className="w-full text-xs font-mono py-2 px-3 bg-neutral-950 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-rose-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px] font-mono text-neutral-400">
                      <span>{lang === 'bn' ? 'ইউটিউব স্ট্রিম কি (Stream Key):' : 'Stream Key:'}</span>
                      <button
                        type="button"
                        onClick={() => setShowKeyMap(prev => ({ ...prev, [target.id]: !prev[target.id] }))}
                        className="text-neutral-500 hover:text-neutral-300 flex items-center gap-1"
                      >
                        {showKeyMap[target.id] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        <span>{showKeyMap[target.id] ? 'লুকান' : 'দেখান'}</span>
                      </button>
                    </div>
                    <div className="relative">
                      <input
                        type={showKeyMap[target.id] ? 'text' : 'password'}
                        value={target.streamKey}
                        onChange={e => {
                          const updated = [...localTargets];
                          updated[idx].streamKey = e.target.value;
                          setLocalTargets(updated);
                        }}
                        placeholder="s9bj-akha-6097-ykvq-bvad"
                        className="w-full text-xs font-mono py-2 px-3 bg-neutral-950 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-rose-500"
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 3: VIDEO SWITCHER & UPLOAD */}
      {activeAdminSubTab === 'playlist' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
                <Film className="w-4 h-4 text-sky-400" />
                <span>{lang === 'bn' ? 'ভিডিও প্লেলিস্ট ও লাইভ সুইচিং' : 'Video Playlist & Live Switcher'}</span>
              </h3>
              <p className="text-xs text-neutral-400">
                {lang === 'bn'
                  ? 'যেকোনো ভিডিওর পাশের "লাইভে চালান" বাটনে চাপ দিলে সরাসরি ইউটিউবে সেই ভিডিও চলতে থাকবে।'
                  : 'Click "Play Live Now" next to any video to immediately switch the YouTube broadcast feed.'}
              </p>
            </div>

            {/* Direct File Upload */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <input
                ref={fileInputRef}
                type="file"
                accept="video/mp4,video/mkv,video/quicktime"
                onChange={handleFileUpload}
                className="hidden"
                id="admin-video-upload"
              />
              <label
                htmlFor="admin-video-upload"
                className="cursor-pointer flex-1 sm:flex-initial flex items-center justify-center gap-2 py-2 px-4 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold font-mono transition-all shadow-md shadow-rose-950/60"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{lang === 'bn' ? 'নতুন ভিডিও আপলোড করুন' : 'Upload Video File'}</span>
              </label>
            </div>
          </div>

          {/* Upload Status Banner */}
          {uploadStatus && (
            <div className="p-3 rounded-lg bg-sky-950/40 border border-sky-500/50 text-sky-300 text-xs font-mono flex items-center gap-2">
              <div className="w-3.5 h-3.5 border-2 border-sky-400 border-t-transparent rounded-full animate-spin" />
              <span>{uploadStatus}</span>
            </div>
          )}

          {/* Add Online Video Link */}
          <form onSubmit={handleAddVideoUrl} className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-3">
            <div className="text-xs font-bold text-neutral-300 font-mono">
              {lang === 'bn' ? 'অনলাইন সরাসরি ভিডিও লিংক যোগ করুন (Direct MP4 URL)' : 'Add Direct Video URL'}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
              <input
                type="text"
                placeholder={lang === 'bn' ? 'ভিডিও শিরোনাম (ঐচ্ছিক)' : 'Video Title (Optional)'}
                value={newVideoTitle}
                onChange={e => setNewVideoTitle(e.target.value)}
                className="sm:col-span-4 text-xs font-mono py-2 px-3 bg-neutral-950 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-rose-500"
              />
              <input
                type="url"
                placeholder="https://example.com/stream.mp4"
                value={newVideoUrl}
                onChange={e => setNewVideoUrl(e.target.value)}
                className="sm:col-span-6 text-xs font-mono py-2 px-3 bg-neutral-950 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-rose-500"
              />
              <button
                type="submit"
                className="sm:col-span-2 py-2 px-3 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-bold font-mono transition-colors flex items-center justify-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>যুক্ত করুন</span>
              </button>
            </div>
          </form>

          {/* Playlist Table */}
          <div className="space-y-2">
            {session.playlist.map((video, index) => {
              const isCurrent = session.currentVideoIndex === index;
              return (
                <div
                  key={video.id || index}
                  className={`p-3.5 rounded-xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                    isCurrent
                      ? 'bg-neutral-900 border-rose-500/80 shadow-md shadow-rose-950/20'
                      : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="w-6 text-center text-xs font-mono text-neutral-500 font-bold">
                      #{index + 1}
                    </span>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-semibold text-white font-mono truncate max-w-xs sm:max-w-md">
                          {video.title}
                        </span>
                        {isCurrent && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-rose-500 text-white animate-pulse">
                            🔴 অন-এয়ার লাইভ
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] font-mono text-neutral-400 flex items-center gap-2 mt-0.5 truncate">
                        <span>{video.resolution || 'HD'}</span>
                        <span>•</span>
                        <span>{Math.floor(video.duration / 60)}m {video.duration % 60}s</span>
                        <span>•</span>
                        <span className="truncate max-w-xs text-neutral-500">{video.url}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
                    {isCurrent ? (
                      <span className="py-1.5 px-3 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-xs font-mono font-bold">
                        চলছে (Playing)
                      </span>
                    ) : (
                      <button
                        onClick={() => onSelectVideo(index)}
                        className="py-1.5 px-3 bg-neutral-800 hover:bg-rose-600 text-neutral-200 hover:text-white rounded-lg text-xs font-mono font-bold transition-all flex items-center gap-1.5 shadow"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>লাইভে চালান</span>
                      </button>
                    )}

                    <button
                      onClick={() => handleDeleteVideo(video.id)}
                      className="p-1.5 text-neutral-500 hover:text-rose-400 hover:bg-neutral-800 rounded-lg transition-colors"
                      title="Delete video"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUB-TAB 4: OVERLAYS & BRANDING */}
      {activeAdminSubTab === 'overlays' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              <span>{lang === 'bn' ? 'অন-স্ক্রিন ব্র্যান্ডিং ও ওভারলে' : 'On-Screen Branding & Overlays'}</span>
            </h3>
            <button
              onClick={handleSaveOverlays}
              disabled={savingOverlays}
              className="py-1.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold font-mono transition-all flex items-center gap-1.5 shadow"
            >
              <Check className="w-3.5 h-3.5" />
              <span>{savingOverlays ? 'সংরক্ষণ হচ্ছে...' : 'সংরক্ষণ করুন'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Watermark Branding */}
            <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
                <span className="text-xs font-bold text-white font-mono">লাইভ ওয়াটারমার্ক (Watermark Text)</span>
                <label className="flex items-center gap-1.5 cursor-pointer text-xs font-mono text-neutral-400">
                  <span>{localOverlays.showWatermark ? 'সক্রিয়' : 'লুকানো'}</span>
                  <input
                    type="checkbox"
                    checked={localOverlays.showWatermark}
                    onChange={e => setLocalOverlays(prev => ({ ...prev, showWatermark: e.target.checked }))}
                    className="accent-rose-500 rounded"
                  />
                </label>
              </div>
              <input
                type="text"
                value={localOverlays.watermarkText}
                onChange={e => setLocalOverlays(prev => ({ ...prev, watermarkText: e.target.value }))}
                className="w-full text-xs font-mono py-2 px-3 bg-neutral-950 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-rose-500"
              />
            </div>

            {/* Live Ticker Scroll */}
            <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
                <span className="text-xs font-bold text-white font-mono">লাইভ টিকার বার্তা (Running Ticker)</span>
                <label className="flex items-center gap-1.5 cursor-pointer text-xs font-mono text-neutral-400">
                  <span>{localOverlays.showTicker ? 'সক্রিয়' : 'লুকানো'}</span>
                  <input
                    type="checkbox"
                    checked={localOverlays.showTicker}
                    onChange={e => setLocalOverlays(prev => ({ ...prev, showTicker: e.target.checked }))}
                    className="accent-rose-500 rounded"
                  />
                </label>
              </div>
              <input
                type="text"
                value={localOverlays.tickerText}
                onChange={e => setLocalOverlays(prev => ({ ...prev, tickerText: e.target.value }))}
                className="w-full text-xs font-mono py-2 px-3 bg-neutral-950 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-rose-500"
              />
            </div>

            {/* Emergency Slate Text */}
            <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-3">
              <span className="text-xs font-bold text-white font-mono">স্লেট স্ক্রিন বার্তা (Be Right Back Message)</span>
              <input
                type="text"
                value={localOverlays.slateText}
                onChange={e => setLocalOverlays(prev => ({ ...prev, slateText: e.target.value }))}
                className="w-full text-xs font-mono py-2 px-3 bg-neutral-950 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-rose-500"
              />
            </div>

            {/* Viewers Counter Base */}
            <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-3">
              <span className="text-xs font-bold text-white font-mono">দর্শক সংখ্যা বেস (Viewer Count Base)</span>
              <input
                type="number"
                value={localOverlays.viewerBase}
                onChange={e => setLocalOverlays(prev => ({ ...prev, viewerBase: parseInt(e.target.value) || 1200 }))}
                className="w-full text-xs font-mono py-2 px-3 bg-neutral-950 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 5: TERMINAL & FFMPEG LOGS */}
      {activeAdminSubTab === 'terminal' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
              <Terminal className="w-4 h-4 text-purple-400" />
              <span>{lang === 'bn' ? 'সার্ভার ও এফএফএমপ্যাগ লাইভ কনসোল' : 'Server & FFmpeg Live Console'}</span>
            </h3>
            <button
              onClick={handleClearLogs}
              className="py-1 px-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded text-xs font-mono transition-colors"
            >
              লগ পরিষ্কার করুন
            </button>
          </div>

          <div className="p-4 rounded-xl bg-black border border-neutral-800 font-mono text-xs space-y-1.5 max-h-96 overflow-y-auto shadow-inner">
            {session.logs && session.logs.length > 0 ? (
              session.logs.map((log, i) => (
                <div key={i} className="flex items-start gap-2 leading-relaxed">
                  <span className="text-neutral-500 shrink-0">[{log.timestamp}]</span>
                  <span
                    className={
                      log.type === 'success'
                        ? 'text-emerald-400'
                        : log.type === 'warn'
                        ? 'text-amber-400'
                        : log.type === 'error'
                        ? 'text-rose-400 font-bold'
                        : 'text-neutral-300'
                    }
                  >
                    {log.message}
                  </span>
                </div>
              ))
            ) : (
              <div className="text-neutral-500">কোনো লগ নেই...</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
