import React, { useState } from 'react';
import { Lock, KeyRound, ShieldAlert, X, Check, Delete } from 'lucide-react';
import { Language } from '../utils/i18n';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  lang: Language;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  lang,
}) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleVerify = async (passToVerify?: string) => {
    const pass = passToVerify !== undefined ? passToVerify : password;
    if (!pass.trim()) {
      setError(lang === 'bn' ? 'অনুগ্রহ করে পাসওয়ার্ড দিন' : 'Please enter passcode');
      return;
    }

    setLoading(true);
    setError(null);

    // Normalize Bengali digits (৯৯০ -> 990)
    const normalized = pass.trim()
      .replace(/০/g, '0').replace(/১/g, '1').replace(/২/g, '2').replace(/৩/g, '3')
      .replace(/৪/g, '4').replace(/৫/g, '5').replace(/৬/g, '6').replace(/৭/g, '7')
      .replace(/৮/g, '8').replace(/৯/g, '9');

    try {
      const res = await fetch('/api/admin/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: normalized }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        localStorage.setItem('siam_admin_token', data.token || 'admin_authenticated');
        onSuccess();
        onClose();
        setPassword('');
      } else {
        setError(data.error || (lang === 'bn' ? 'ভুল পাসওয়ার্ড! অনুগ্রহ করে সঠিক পাসওয়ার্ড দিন।' : 'Incorrect password! Please try again.'));
      }
    } catch (err) {
      // Local fallback check
      if (normalized === '990') {
        localStorage.setItem('siam_admin_token', 'admin_authenticated');
        onSuccess();
        onClose();
        setPassword('');
      } else {
        setError(lang === 'bn' ? 'ভুল পাসওয়ার্ড! অনুগ্রহ করে সঠিক পাসওয়ার্ড দিন।' : 'Incorrect password! Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleKeypadPress = (val: string) => {
    setError(null);
    if (val === 'C') {
      setPassword('');
    } else if (val === 'DEL') {
      setPassword(prev => prev.slice(0, -1));
    } else {
      const nextPass = password + val;
      setPassword(nextPass);
      if (nextPass === '990' || nextPass === '৯৯০') {
        setTimeout(() => handleVerify(nextPass), 100);
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleVerify();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-sm bg-neutral-900 border border-neutral-700/80 rounded-2xl p-6 shadow-2xl space-y-5 text-neutral-100">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center space-y-2 pt-2">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-500 shadow-inner">
            <Lock className="w-7 h-7" />
          </div>
          <h2 className="text-lg font-bold text-white font-mono flex items-center justify-center gap-1.5">
            <span>{lang === 'bn' ? 'অ্যাডমিন প্যানেল প্রবেশ' : 'Admin Panel Access'}</span>
          </h2>
          <p className="text-xs text-neutral-400 leading-relaxed px-2">
            {lang === 'bn'
              ? 'সম্পূর্ণ ব্রডকাস্ট সিস্টেম ও সার্ভার কন্ট্রোল করতে পাসওয়ার্ড দিন।'
              : 'Enter master passcode to unlock all broadcast and server controls.'}
          </p>
        </div>

        {/* Security Badge */}
        <div className="flex items-center justify-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-neutral-800 border border-neutral-700 text-neutral-300 text-xs font-mono font-medium">
            <KeyRound className="w-3.5 h-3.5 text-rose-400" />
            <span>{lang === 'bn' ? 'অনুমোদিত অ্যাডমিন প্রবেশ' : 'Authorized Access Only'}</span>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <input
              type="password"
              inputMode="numeric"
              autoFocus
              value={password}
              onChange={e => {
                setPassword(e.target.value);
                setError(null);
              }}
              placeholder={lang === 'bn' ? 'গোপন পাসওয়ার্ড দিন' : 'Enter security passcode'}
              className="w-full text-center text-xl tracking-widest font-mono py-3 px-4 bg-neutral-950 border border-neutral-700 rounded-xl text-white placeholder:text-neutral-600 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500"
            />
          </div>

          {/* Error Message */}
          {error && (
            <div className="flex items-center justify-center gap-1.5 text-xs text-rose-400 font-medium bg-rose-950/40 border border-rose-900/60 p-2.5 rounded-lg animate-shake">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Touch-Friendly Numeric Keypad for Mobile & Desktop */}
          <div className="grid grid-cols-3 gap-2 pt-1 font-mono">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', 'DEL'].map(btn => (
              <button
                key={btn}
                type="button"
                onClick={() => handleKeypadPress(btn)}
                className={`py-2.5 rounded-lg text-sm font-semibold transition-all active:scale-95 flex items-center justify-center ${
                  btn === 'C'
                    ? 'bg-neutral-800 text-neutral-400 hover:text-white hover:bg-neutral-700'
                    : btn === 'DEL'
                    ? 'bg-neutral-800 text-neutral-400 hover:text-white hover:bg-neutral-700'
                    : 'bg-neutral-950 hover:bg-neutral-800 text-neutral-100 border border-neutral-800'
                }`}
              >
                {btn === 'DEL' ? <Delete className="w-4 h-4" /> : btn}
              </button>
            ))}
          </div>

          {/* Submit Action */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 px-4 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-sm font-bold tracking-wide transition-all flex items-center justify-center gap-2 shadow-lg shadow-rose-950/60 disabled:opacity-50"
          >
            {loading ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Check className="w-4 h-4" />
            )}
            <span>{lang === 'bn' ? 'অ্যাডমিন প্যানেল আনলক করুন' : 'Unlock Admin Panel'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
