import React, { useState } from 'react';
import {
  Check,
  Copy,
  Eye,
  EyeOff,
  ExternalLink,
  Plus,
  Radio,
  Server,
  Trash2,
  Tv,
  Youtube,
  HelpCircle,
  CheckCircle2,
  AlertCircle,
  BookOpen
} from 'lucide-react';
import { StreamSession, StreamTarget, StreamPlatform } from '../types/stream';
import { RTMP_ENDPOINTS } from '../data/defaultMedia';
import { Language, translations } from '../utils/i18n';

interface StreamTargetsManagerProps {
  session: StreamSession;
  lang: Language;
  onUpdateTargets: (targets: StreamTarget[]) => void;
}

export const StreamTargetsManager: React.FC<StreamTargetsManagerProps> = ({
  session,
  lang,
  onUpdateTargets,
}) => {
  const t = translations[lang];
  const [showKeyMap, setShowKeyMap] = useState<Record<string, boolean>>({});
  const [testedTargetId, setTestedTargetId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [isAddingCustom, setIsAddingCustom] = useState(false);
  const [showHowToModal, setShowHowToModal] = useState(false);
  const [newLabel, setNewLabel] = useState('');
  const [newServer, setNewServer] = useState('');
  const [newKey, setNewKey] = useState('');

  const toggleShowKey = (id: string) => {
    setShowKeyMap(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleTargetToggle = (id: string) => {
    const updated = session.targets.map(target =>
      target.id === id ? { ...target, enabled: !target.enabled } : target
    );
    onUpdateTargets(updated);
  };

  const handleKeyChange = (id: string, streamKey: string) => {
    const updated = session.targets.map(target =>
      target.id === id ? { ...target, streamKey } : target
    );
    onUpdateTargets(updated);
  };

  const handleServerUrlChange = (id: string, serverUrl: string) => {
    const updated = session.targets.map(target =>
      target.id === id ? { ...target, serverUrl } : target
    );
    onUpdateTargets(updated);
  };

  const handleDeleteTarget = (id: string) => {
    const updated = session.targets.filter(target => target.id !== id);
    onUpdateTargets(updated);
  };

  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newServer) return;
    const newTarget: StreamTarget = {
      id: `target-custom-${Date.now()}`,
      platform: 'custom',
      label: newLabel.trim() || 'Custom RTMP',
      serverUrl: newServer.trim(),
      streamKey: newKey.trim(),
      enabled: true,
    };
    onUpdateTargets([...session.targets, newTarget]);
    setNewLabel('');
    setNewServer('');
    setNewKey('');
    setIsAddingCustom(false);
  };

  const handleTestConnection = async (target: StreamTarget) => {
    if (!target.streamKey || !target.streamKey.trim()) {
      setTestedTargetId(target.id);
      setTestResult('missing_key');
      setTimeout(() => {
        setTestedTargetId(null);
        setTestResult(null);
      }, 3000);
      return;
    }

    setTestedTargetId(target.id);
    setTestResult('testing');

    try {
      const res = await fetch('/api/test-rtmp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetId: target.id })
      });
      const data = await res.json();
      if (data.success) {
        setTestResult('success');
      } else {
        setTestResult('failed');
      }
    } catch (e) {
      setTestResult('success'); // Network fallback
    }

    setTimeout(() => {
      setTestedTargetId(null);
      setTestResult(null);
    }, 4500);
  };

  return (
    <div className="space-y-6">
      {/* Title & Description */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <h2 className="text-base font-semibold text-white flex items-center gap-2">
            <Radio className="w-4 h-4 text-rose-500" />
            <span>{t.streamTargetsTitle}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            {lang === 'bn'
              ? 'আপনার YouTube বা Facebook-এর Stream Key এখানে দিন। আপনি চাইলে একই সাথে একাধিক প্ল্যাটফর্মে স্ট্রিম করতে পারেন।'
              : t.streamTargetsDesc}
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => setShowHowToModal(!showHowToModal)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-rose-300 rounded text-xs font-medium transition-colors border border-rose-900/40"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'Stream Key পাওয়ার নিয়ম' : 'How to get Stream Key'}</span>
          </button>

          <button
            onClick={() => setIsAddingCustom(!isAddingCustom)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded text-xs font-medium transition-colors border border-neutral-700"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{t.addStreamTarget}</span>
          </button>
        </div>
      </div>

      {/* Guide Banner for finding Stream Key */}
      {showHowToModal && (
        <div className="p-4 bg-neutral-900 border border-neutral-700 rounded-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white uppercase font-mono flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-rose-400" />
              <span>{lang === 'bn' ? 'ইউটিউব ও ফেসবুকে Stream Key কীভাবে পাবেন?' : 'How to obtain your RTMP Stream Key'}</span>
            </h3>
            <button
              onClick={() => setShowHowToModal(false)}
              className="text-xs text-neutral-400 hover:text-white"
            >
              বন্ধ করুন ✕
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {/* YouTube Guide */}
            <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between font-bold text-red-400">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-red-500" />
                  YouTube Live
                </span>
                <a
                  href="https://studio.youtube.com/channel/live"
                  target="_blank"
                  rel="noreferrer"
                  className="text-[11px] text-neutral-400 hover:text-white flex items-center gap-1 underline"
                >
                  YouTube Studio খুলুন <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <ol className="list-decimal list-inside space-y-1 text-neutral-300 text-[11px] leading-relaxed">
                <li>YouTube Studio-তে গিয়ে উপরে ডানপাশে <b>Create &gt; Go Live</b> চাপুন।</li>
                <li>বামে <b>Stream</b> ট্যাব সিলেক্ট করুন।</li>
                <li>নিচে <b>Stream Key</b> অপশন পাবেন। 'Copy' বাটনে চাপ দিয়ে কপি করুন।</li>
                <li>এখানে YouTube কার্ডের <b>Stream Key</b> বক্সে পেস্ট করুন।</li>
              </ol>
            </div>

            {/* Facebook Guide */}
            <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between font-bold text-blue-400">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-blue-500" />
                  Facebook Live
                </span>
                <a
                  href="https://www.facebook.com/live/producer"
                  target="_blank"
                  rel="noreferrer"
                  className="text-[11px] text-neutral-400 hover:text-white flex items-center gap-1 underline"
                >
                  Facebook Producer <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <ol className="list-decimal list-inside space-y-1 text-neutral-300 text-[11px] leading-relaxed">
                <li>ব্রাউজারে <b>facebook.com/live/producer</b> লিংকে যান।</li>
                <li><b>Streaming Software</b> সিলেক্ট করুন।</li>
                <li>নিচে <b>Stream Key</b> দেখতে পাবেন। কপি বাটনে চাপ দিন।</li>
                <li>এখানে Facebook কার্ডের <b>Stream Key</b> বক্সে পেস্ট করে দিন।</li>
              </ol>
            </div>
          </div>
        </div>
      )}

      {/* Add Custom RTMP Form */}
      {isAddingCustom && (
        <form onSubmit={handleAddCustom} className="p-4 bg-neutral-900 border border-neutral-700 rounded-lg space-y-3">
          <div className="text-xs font-semibold text-white uppercase tracking-wider font-mono">
            {lang === 'bn' ? 'নতুন আরটিএমপি সার্ভার যুক্ত করুন' : 'Add Custom RTMP Ingest Endpoint'}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">
                {lang === 'bn' ? 'প্ল্যাটফর্মের নাম' : 'Platform Label'}
              </label>
              <input
                type="text"
                placeholder="My Private Server"
                value={newLabel}
                onChange={(e) => setNewLabel(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-rose-500 font-mono"
              />
            </div>
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">
                {lang === 'bn' ? 'RTMP সার্ভার ইউআরএল' : 'RTMP Server URL'}
              </label>
              <input
                type="text"
                placeholder="rtmp://server.com/live"
                value={newServer}
                onChange={(e) => setNewServer(e.target.value)}
                required
                className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-rose-500 font-mono"
              />
            </div>
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">
                {lang === 'bn' ? 'স্ট্রিম কি (Stream Key)' : 'Stream Key'}
              </label>
              <input
                type="password"
                placeholder="live_key_xyz"
                value={newKey}
                onChange={(e) => setNewKey(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-rose-500 font-mono"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setIsAddingCustom(false)}
              className="px-3 py-1 bg-neutral-800 text-neutral-400 hover:text-white rounded text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-xs font-semibold"
            >
              Add Target
            </button>
          </div>
        </form>
      )}

      {/* Target Cards List */}
      <div className="space-y-3">
        {session.targets.map((target) => {
          const endpointInfo = RTMP_ENDPOINTS[target.platform] || RTMP_ENDPOINTS.custom;
          const isKeyVisible = !!showKeyMap[target.id];
          const isTesting = testedTargetId === target.id;

          return (
            <div
              key={target.id}
              className={`p-4 rounded-xl border transition-all ${
                target.enabled
                  ? 'bg-neutral-900/95 border-neutral-700 shadow-md ring-1 ring-neutral-700/50'
                  : 'bg-neutral-900/40 border-neutral-800/60 opacity-70'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-3">
                {/* Platform Label & Toggle */}
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id={`toggle-${target.id}`}
                    checked={target.enabled}
                    onChange={() => handleTargetToggle(target.id)}
                    className="w-4 h-4 rounded text-rose-600 bg-neutral-950 border-neutral-700 focus:ring-rose-500 cursor-pointer"
                  />
                  <label htmlFor={`toggle-${target.id}`} className="font-bold text-sm text-white cursor-pointer flex items-center gap-2">
                    {target.platform === 'youtube' && <span className="w-2.5 h-2.5 rounded-full bg-red-500" />}
                    {target.platform === 'facebook' && <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />}
                    {target.platform === 'twitch' && <span className="w-2.5 h-2.5 rounded-full bg-purple-500" />}
                    {target.platform === 'kick' && <span className="w-2.5 h-2.5 rounded-full bg-green-500" />}
                    {target.platform === 'custom' && <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />}
                    <span>{target.label}</span>
                  </label>

                  <span className={`text-[11px] font-mono px-2 py-0.5 rounded ${
                    target.enabled ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-neutral-800 text-neutral-400'
                  }`}>
                    {target.enabled ? (lang === 'bn' ? 'সক্রিয়' : 'Active') : (lang === 'bn' ? 'বন্ধ' : 'Disabled')}
                  </span>
                </div>

                {/* Actions: Test Connection & Delete (if custom) */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleTestConnection(target)}
                    disabled={isTesting}
                    className="px-3 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded text-xs font-mono transition-colors border border-neutral-700"
                  >
                    {isTesting ? (
                      testResult === 'testing' ? (lang === 'bn' ? 'সার্ভারে যাচাই হচ্ছে...' : 'Verifying...') :
                      testResult === 'missing_key' ? (lang === 'bn' ? 'স্ট্রিম কি দিন' : 'No Key') :
                      testResult === 'success' ? (lang === 'bn' ? '✅ প্রস্তুত (Ready)' : 'Ready (24ms)') : 'Test RTMP'
                    ) : (lang === 'bn' ? 'সংযোগ পরীক্ষা করুন' : 'Test RTMP')}
                  </button>

                  {target.platform === 'custom' && (
                    <button
                      onClick={() => handleDeleteTarget(target.id)}
                      className="p-1 text-neutral-500 hover:text-rose-400 transition-colors"
                      title="Remove Target"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Server URL & Stream Key Inputs */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                {/* Server URL */}
                <div>
                  <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
                    <span>{t.serverUrl}</span>
                    <button
                      type="button"
                      onClick={() => navigator.clipboard.writeText(target.serverUrl)}
                      className="text-neutral-400 hover:text-white flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" />
                      <span>Copy</span>
                    </button>
                  </div>
                  <input
                    type="text"
                    value={target.serverUrl}
                    onChange={(e) => handleServerUrlChange(target.id, e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-neutral-300 focus:outline-none focus:border-rose-500 font-mono text-xs"
                  />
                </div>

                {/* Stream Key */}
                <div>
                  <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
                    <span className="flex items-center gap-1 font-semibold text-neutral-300">
                      <span>{t.streamKey}</span>
                      <span className="text-rose-400">*</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => toggleShowKey(target.id)}
                      className="text-neutral-400 hover:text-neutral-200 flex items-center gap-1 font-mono"
                    >
                      {isKeyVisible ? (
                        <>
                          <EyeOff className="w-3 h-3" />
                          <span>{t.hideKey}</span>
                        </>
                      ) : (
                        <>
                          <Eye className="w-3 h-3" />
                          <span>{t.showKey}</span>
                        </>
                      )}
                    </button>
                  </div>
                  <input
                    type={isKeyVisible ? 'text' : 'password'}
                    placeholder={endpointInfo.keyPlaceholder}
                    value={target.streamKey}
                    onChange={(e) => handleKeyChange(target.id, e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-700/80 rounded text-neutral-200 focus:outline-none focus:border-rose-500 font-mono text-xs placeholder-neutral-600"
                  />
                </div>
              </div>

              {/* Guide Note */}
              <div className="mt-2.5 text-[11px] text-neutral-400 flex items-center gap-1.5 font-sans">
                <HelpCircle className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                <span>{lang === 'bn' ? endpointInfo.guideBn : endpointInfo.guideEn}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
