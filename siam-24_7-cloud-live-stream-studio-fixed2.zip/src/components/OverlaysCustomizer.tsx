import React from 'react';
import {
  Sliders,
  Type,
  Clock,
  Eye,
  AlertTriangle,
  Volume2,
  VolumeX,
  Palette,
  CheckCircle2,
  Tv
} from 'lucide-react';
import { OverlayConfig } from '../types/stream';
import { Language, translations } from '../utils/i18n';

interface OverlaysCustomizerProps {
  overlays: OverlayConfig;
  lang: Language;
  onUpdateOverlays: (updated: Partial<OverlayConfig>) => void;
}

export const OverlaysCustomizer: React.FC<OverlaysCustomizerProps> = ({
  overlays,
  lang,
  onUpdateOverlays,
}) => {
  const t = translations[lang];

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="pb-2 border-b border-neutral-800">
        <h2 className="text-base font-semibold text-white flex items-center gap-2">
          <Palette className="w-4 h-4 text-rose-500" />
          <span>{t.overlaysTitle}</span>
        </h2>
        <p className="text-xs text-neutral-400 mt-0.5">
          {lang === 'bn'
            ? 'লাইভ স্ক্রিনে প্রদর্শিত ওয়াটারমার্ক, স্ক্রলিং টেক্সট, ঘড়ি ও জরুরি বিরতি কাস্টমাইজ করুন'
            : 'Customize real-time on-screen broadcast watermarks, ticker marquee, clock & slates'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        {/* 1. Watermark / Logo Card */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-semibold text-white">
              <Type className="w-4 h-4 text-rose-400" />
              <span>{t.watermarkText}</span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={overlays.showWatermark}
                onChange={(e) => onUpdateOverlays({ showWatermark: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-neutral-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-rose-600"></div>
            </label>
          </div>

          <div>
            <label className="block text-[11px] text-neutral-400 mb-1">
              {lang === 'bn' ? 'লোগো টেক্সট (শীর্ষ ডান কোণে)' : 'Watermark Logo (Top-Right Corner)'}
            </label>
            <input
              type="text"
              value={overlays.watermarkText}
              onChange={(e) => onUpdateOverlays({ watermarkText: e.target.value })}
              placeholder="SIAM LIVE 24/7"
              className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-neutral-200 focus:outline-none focus:border-rose-500 font-mono text-xs"
            />
          </div>
        </div>

        {/* 2. Scrolling News / Alert Ticker */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-semibold text-white">
              <Tv className="w-4 h-4 text-amber-400" />
              <span>{t.tickerText}</span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={overlays.showTicker}
                onChange={(e) => onUpdateOverlays({ showTicker: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-neutral-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-rose-600"></div>
            </label>
          </div>

          <div>
            <label className="block text-[11px] text-neutral-400 mb-1">
              {lang === 'bn' ? 'স্ক্রলিং নোটিশ বা ব্রেকিং টেক্সট' : 'Marquee Scrolling Text (Bottom Bar)'}
            </label>
            <textarea
              rows={2}
              value={overlays.tickerText}
              onChange={(e) => onUpdateOverlays({ tickerText: e.target.value })}
              placeholder="🔴 সরাসরি সম্প্রচার চলছে • ২৪/৭ আনলিমিটেড স্ট্রিমিং • Siam Cloud Studio"
              className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-neutral-200 focus:outline-none focus:border-rose-500 text-xs resize-none"
            />
          </div>
        </div>

        {/* 3. Live Clock & Timezone */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-semibold text-white">
              <Clock className="w-4 h-4 text-sky-400" />
              <span>{t.clockDisplay}</span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={overlays.showClock}
                onChange={(e) => onUpdateOverlays({ showClock: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-neutral-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-rose-600"></div>
            </label>
          </div>

          <div>
            <label className="block text-[11px] text-neutral-400 mb-1">
              {lang === 'bn' ? 'টাইমজোন (Timezone)' : 'Clock Timezone'}
            </label>
            <select
              value={overlays.clockTimezone}
              onChange={(e) => onUpdateOverlays({ clockTimezone: e.target.value })}
              className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-neutral-200 focus:outline-none focus:border-rose-500 font-mono text-xs"
            >
              <option value="Asia/Dhaka">Asia/Dhaka (BST, UTC+6)</option>
              <option value="UTC">UTC (Universal Coordinated Time)</option>
              <option value="America/New_York">America/New_York (EST/EDT)</option>
              <option value="Europe/London">Europe/London (GMT/BST)</option>
              <option value="Asia/Dubai">Asia/Dubai (GST, UTC+4)</option>
            </select>
          </div>
        </div>

        {/* 4. Live Viewers Simulator */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-semibold text-white">
              <Eye className="w-4 h-4 text-emerald-400" />
              <span>{t.viewerCounter}</span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={overlays.showViewers}
                onChange={(e) => onUpdateOverlays({ showViewers: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-neutral-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-rose-600"></div>
            </label>
          </div>

          <div>
            <label className="block text-[11px] text-neutral-400 mb-1">
              {lang === 'bn' ? 'বেস ভিউয়ার সংখ্যা' : 'Base Viewer Count'}
            </label>
            <input
              type="number"
              min="0"
              max="1000000"
              value={overlays.viewerBase}
              onChange={(e) => onUpdateOverlays({ viewerBase: Math.max(0, Number(e.target.value)) })}
              className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-neutral-200 focus:outline-none focus:border-rose-500 font-mono text-xs"
            />
          </div>
        </div>

        {/* 5. Emergency Slate / Standby Screen */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3 md:col-span-2">
          <div className="flex items-center gap-2 font-semibold text-white">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            <span>{lang === 'bn' ? 'জরুরি বিরতি স্ক্রিন সেটিংস (Be Right Back Slate)' : 'Emergency Slate Screen Settings'}</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">
                {lang === 'bn' ? 'বিরতি কার্ডে টেক্সট' : 'Standby Message'}
              </label>
              <input
                type="text"
                value={overlays.slateText}
                onChange={(e) => onUpdateOverlays({ slateText: e.target.value })}
                placeholder="শীঘ্রই ফিরে আসছি • Be Right Back"
                className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-neutral-200 focus:outline-none focus:border-rose-500 text-xs"
              />
            </div>
            <div className="flex items-center justify-between p-2 bg-neutral-950 rounded border border-neutral-800">
              <span className="text-[11px] text-neutral-400">
                {lang === 'bn' ? 'টেস্ট প্যাটার্ন ব্যাকগ্রাউন্ড:' : 'Standby Pattern:'} SMPTE Color Bars
              </span>
              <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Ready
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
