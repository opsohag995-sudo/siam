import React, { useState } from 'react';
import { HelpCircle, ChevronRight, CheckCircle2, Youtube, Video, Play, Zap, ArrowRight, Laptop, Radio } from 'lucide-react';
import { Language } from '../utils/i18n';

interface QuickStartGuideProps {
  lang: Language;
  onGoToTab: (tab: 'dashboard' | 'streams' | 'media' | 'studio' | 'server') => void;
}

export const QuickStartGuide: React.FC<QuickStartGuideProps> = ({ lang, onGoToTab }) => {
  const [activeStep, setActiveStep] = useState(1);

  return (
    <div className="bg-gradient-to-br from-neutral-900 via-neutral-900 to-neutral-950 border border-neutral-800 rounded-xl p-5 shadow-lg space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-neutral-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
            <Radio className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">
              {lang === 'bn' ? 'মাত্র ৩টি ধাপে আপনার চ্যানেলে ২৪/৭ লাইভ স্ট্রিম চালু করার নিয়ম' : 'How It Works: Start 24/7 Live Stream in 3 Easy Steps'}
            </h2>
            <p className="text-xs text-neutral-400">
              {lang === 'bn'
                ? 'একদম সহজ! নিচের ৩টি কাজ করলেই আপনার চ্যানেলে অবিরাম লাইভ শুরু হয়ে যাবে।'
                : 'Simple setup! Follow these 3 steps to broadcast 24/7 non-stop.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-xs font-mono text-neutral-400 self-start sm:self-auto bg-neutral-950 px-3 py-1 rounded border border-neutral-800">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>{lang === 'bn' ? 'সহজ গাইডলাইন' : 'Quick Guide'}</span>
        </div>
      </div>

      {/* 3 Step Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Step 1 */}
        <div
          onClick={() => { setActiveStep(1); onGoToTab('streams'); }}
          className={`p-3.5 rounded-lg border cursor-pointer transition-all ${
            activeStep === 1
              ? 'bg-rose-950/20 border-rose-500/50 shadow-md'
              : 'bg-neutral-950/60 border-neutral-800/80 hover:bg-neutral-950'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="w-6 h-6 rounded-full bg-rose-600 text-white font-bold text-xs flex items-center justify-center font-mono">
              ১
            </span>
            <span className="text-[11px] font-mono text-rose-400 font-semibold">ধাপ ১</span>
          </div>
          <h3 className="text-xs font-bold text-white mb-1">
            {lang === 'bn' ? 'স্ট্রিম কি (Stream Key) বসান' : 'Enter Stream Key'}
          </h3>
          <p className="text-[11px] text-neutral-400 leading-relaxed">
            {lang === 'bn'
              ? 'YouTube Studio বা Facebook Live-এ যান। সেখান থেকে আপনার লাইভের "Stream Key" কপি করে এখানে পেস্ট করুন।'
              : 'Copy your Stream Key from YouTube Studio or Facebook Live Producer and paste it here.'}
          </p>
          <div className="mt-3 text-[11px] text-rose-400 font-medium flex items-center gap-1">
            <span>{lang === 'bn' ? 'চ্যানেল সেটিংসে যান' : 'Go to Stream Keys'}</span>
            <ChevronRight className="w-3 h-3" />
          </div>
        </div>

        {/* Step 2 */}
        <div
          onClick={() => { setActiveStep(2); onGoToTab('media'); }}
          className={`p-3.5 rounded-lg border cursor-pointer transition-all ${
            activeStep === 2
              ? 'bg-rose-950/20 border-rose-500/50 shadow-md'
              : 'bg-neutral-950/60 border-neutral-800/80 hover:bg-neutral-950'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="w-6 h-6 rounded-full bg-neutral-800 text-neutral-200 font-bold text-xs flex items-center justify-center font-mono">
              ২
            </span>
            <span className="text-[11px] font-mono text-neutral-400 font-semibold">ধাপ ২</span>
          </div>
          <h3 className="text-xs font-bold text-white mb-1">
            {lang === 'bn' ? 'ভিডিও আপলোড বা সিলেক্ট করুন' : 'Upload or Pick Video'}
          </h3>
          <p className="text-[11px] text-neutral-400 leading-relaxed">
            {lang === 'bn'
              ? 'আপনার ফোন বা কম্পিউটারের যে ভিডিওটি লাইভ চালাতে চান তা আপলোড করুন, অথবা আমাদের রেডিমেড প্লেলিস্ট ব্যবহার করুন।'
              : 'Upload any video file (.mp4) from your device or use the pre-loaded 24/7 video loops.'}
          </p>
          <div className="mt-3 text-[11px] text-neutral-300 font-medium flex items-center gap-1">
            <span>{lang === 'bn' ? 'ভিডিও লাইব্রেরিতে যান' : 'Open Video Library'}</span>
            <ChevronRight className="w-3 h-3" />
          </div>
        </div>

        {/* Step 3 */}
        <div
          onClick={() => { setActiveStep(3); onGoToTab('dashboard'); }}
          className={`p-3.5 rounded-lg border cursor-pointer transition-all ${
            activeStep === 3
              ? 'bg-rose-950/20 border-rose-500/50 shadow-md'
              : 'bg-neutral-950/60 border-neutral-800/80 hover:bg-neutral-950'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center font-mono">
              ৩
            </span>
            <span className="text-[11px] font-mono text-emerald-400 font-semibold">ধাপ ৩</span>
          </div>
          <h3 className="text-xs font-bold text-white mb-1">
            {lang === 'bn' ? '"লাইভ শুরু করুন" বাটনে চাপুন' : 'Click "Start Stream"'}
          </h3>
          <p className="text-[11px] text-neutral-400 leading-relaxed">
            {lang === 'bn'
              ? 'উপরে লাল বাটনে চাপ দিন। ব্যস! লাইভ শুরু হয়ে গেলে আপনি পিসি বন্ধ বা ইন্টারনেট অফ করে দিলেও ২৪/৭ চলবে।'
              : 'Hit the Start Stream button. Once live, the server broadcasts continuously even if you turn off your PC!'}
          </p>
          <div className="mt-3 text-[11px] text-emerald-400 font-medium flex items-center gap-1">
            <span>{lang === 'bn' ? 'ড্যাশবোর্ডে লাইভ মনিটর দেখুন' : 'View Live Monitor'}</span>
            <ChevronRight className="w-3 h-3" />
          </div>
        </div>
      </div>
    </div>
  );
};
