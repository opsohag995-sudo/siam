import React, { useRef, useState, useEffect } from 'react';
import {
  Volume2,
  VolumeX,
  Maximize2,
  AlertCircle,
  Eye,
  Clock,
  Radio,
  Sliders,
  Sparkles,
  Flame,
  Play
} from 'lucide-react';
import { StreamSession, VideoItem } from '../types/stream';
import { Language, translations } from '../utils/i18n';

interface BroadcastMonitorProps {
  session: StreamSession;
  lang: Language;
  onToggleSlate: () => void;
  onVolumeChange: (vol: number) => void;
  onMuteToggle: () => void;
}

export const BroadcastMonitor: React.FC<BroadcastMonitorProps> = ({
  session,
  lang,
  onToggleSlate,
  onVolumeChange,
  onMuteToggle,
}) => {
  const t = translations[lang];
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [currentTimeStr, setCurrentTimeStr] = useState('');
  const [needsUserInteraction, setNeedsUserInteraction] = useState(false);

  const currentVideo: VideoItem | undefined = session.playlist[session.currentVideoIndex] || session.playlist[0];
  const isLive = session.status === 'live';
  const isSlateActive = session.isSlateActive;

  // Real-time clock for stream overlay
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      try {
        const timeFormatted = now.toLocaleTimeString('en-US', {
          timeZone: session.overlays.clockTimezone || 'Asia/Dhaka',
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        });
        setCurrentTimeStr(`${timeFormatted} BST`);
      } catch (e) {
        setCurrentTimeStr(now.toLocaleTimeString());
      }
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [session.overlays.clockTimezone]);

  // Synchronize local preview video with server playback & handle mobile autoplay rules
  useEffect(() => {
    if (videoRef.current && currentVideo) {
      const vid = videoRef.current;
      if (!vid.src || !vid.src.includes(currentVideo.url)) {
        vid.src = currentVideo.url;
      }

      vid.volume = session.overlays.isMuted ? 0 : session.overlays.audioVolume / 100;
      // Force muted for mobile autoplay compliance if needed
      vid.muted = session.overlays.isMuted;

      const playPromise = vid.play();
      if (playPromise !== undefined) {
        playPromise.catch((err) => {
          // Autoplay policy prevented playback, prompt user to tap
          console.log('Mobile autoplay note:', err);
          setNeedsUserInteraction(true);
        });
      }
    }
  }, [currentVideo, session.currentVideoIndex, session.overlays.audioVolume, session.overlays.isMuted]);

  const handleManualPlay = () => {
    if (videoRef.current) {
      videoRef.current.play().then(() => {
        setNeedsUserInteraction(false);
      }).catch(() => {
        // Fallback: try muted play
        if (videoRef.current) {
          videoRef.current.muted = true;
          videoRef.current.play().then(() => setNeedsUserInteraction(false)).catch(() => {});
        }
      });
    }
  };

  const toggleFullscreen = () => {
    if (containerRef.current) {
      if (!document.fullscreenElement) {
        containerRef.current.requestFullscreen().catch(() => {});
      } else {
        document.exitFullscreen().catch(() => {});
      }
    }
  };

  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-lg overflow-hidden shadow-xl flex flex-col">
      {/* Monitor Header */}
      <div className="bg-neutral-950 px-3 sm:px-4 py-2.5 border-b border-neutral-800 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse shrink-0" />
          <h2 className="text-xs font-semibold uppercase tracking-wider text-neutral-300 font-mono shrink-0">
            {t.previewTitle}
          </h2>
          <span className="text-neutral-600 hidden sm:inline">·</span>
          <span className="text-xs text-neutral-400 font-mono truncate">
            {currentVideo ? currentVideo.title : 'No Video'}
          </span>
        </div>

        {/* Emergency Slate Quick Trigger */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onToggleSlate}
            className={`px-2 sm:px-2.5 py-1 text-xs font-medium rounded transition-colors flex items-center gap-1.5 ${
              isSlateActive
                ? 'bg-amber-500 text-neutral-950 font-bold'
                : 'bg-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-700'
            }`}
            title="Toggle Emergency Slate / BRB Screen"
          >
            <AlertCircle className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isSlateActive ? t.slateActive : t.slateToggle}</span>
            <span className="sm:hidden">{isSlateActive ? 'BRB' : 'Slate'}</span>
          </button>
        </div>
      </div>

      {/* Video Viewport with Broadcast Overlays */}
      <div
        ref={containerRef}
        className="relative aspect-video bg-neutral-950 flex items-center justify-center overflow-hidden select-none"
      >
        {/* If Emergency Slate is Active */}
        {isSlateActive ? (
          <div className="relative w-full h-full">
            <img
              src="/src/assets/images/stream_test_card_1790524803882.jpg"
              alt="Stream Standby Card"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-neutral-950/70 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center">
              <span className="w-4 h-4 rounded-full bg-amber-500 animate-ping mb-3" />
              <h3 className="text-xl md:text-2xl font-bold text-white tracking-wide font-mono mb-2">
                {session.overlays.slateText || 'শীঘ্রই ফিরে আসছি • BE RIGHT BACK'}
              </h3>
              <p className="text-xs text-neutral-400 max-w-md">
                লাইভ সম্প্রচার সাময়িক বিরতিতে রয়েছে। ভিডিও স্ট্রীম ব্যাকগ্রাউন্ডে রেডি আছে।
              </p>
            </div>
          </div>
        ) : (
          /* Normal Live Video Player with mobile fallbacks */
          <>
            <video
              ref={videoRef}
              src={currentVideo?.url}
              autoPlay
              loop
              playsInline
              webkit-playsinline="true"
              muted={session.overlays.isMuted}
              className="w-full h-full object-contain bg-black"
            />

            {/* Tap to Play Overlay for mobile browsers if autoplay was blocked */}
            {needsUserInteraction && (
              <div
                onClick={handleManualPlay}
                className="absolute inset-0 bg-neutral-950/80 z-30 flex flex-col items-center justify-center cursor-pointer p-4 text-center"
              >
                <div className="w-12 h-12 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg mb-2 transition-transform hover:scale-110">
                  <Play className="w-6 h-6 fill-current ml-1" />
                </div>
                <div className="text-xs font-semibold text-white">
                  {lang === 'bn' ? 'ভিডিও প্রিভিউ চালাতে ট্যাপ করুন' : 'Tap to start preview video'}
                </div>
                <div className="text-[11px] text-neutral-400 mt-1">
                  (মোবাইল ব্রাউজারে সাউন্ড পারমিশনের জন্য)
                </div>
              </div>
            )}
          </>
        )}

        {/* OVERLAY 1: Top-Right Watermark / Brand Logo */}
        {session.overlays.showWatermark && !isSlateActive && (
          <div className="absolute top-3 right-3 sm:top-4 sm:right-4 z-20 pointer-events-none">
            <div className="bg-neutral-950/80 backdrop-blur-md border border-neutral-700/50 px-2 sm:px-3 py-1 rounded text-[10px] sm:text-xs font-mono font-bold tracking-wider text-rose-400 flex items-center gap-1.5 shadow-lg">
              <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-rose-500 animate-pulse" />
              {session.overlays.watermarkText || 'SIAM LIVE 24/7'}
            </div>
          </div>
        )}

        {/* OVERLAY 2: Top-Left Broadcast Metrics & Clock */}
        <div className="absolute top-3 left-3 sm:top-4 sm:left-4 z-20 flex items-center gap-1.5 sm:gap-2 pointer-events-none">
          {/* LIVE Badge */}
          <div className="bg-rose-600 text-white font-mono text-[10px] sm:text-xs font-bold px-1.5 sm:px-2 py-0.5 rounded shadow">
            {isLive ? 'LIVE' : 'STANDBY'}
          </div>

          {/* Viewer count */}
          {session.overlays.showViewers && isLive && (
            <div className="bg-neutral-950/80 backdrop-blur-md border border-neutral-800 px-1.5 sm:px-2 py-0.5 rounded text-[10px] sm:text-xs font-mono text-neutral-200 flex items-center gap-1 shadow">
              <Eye className="w-3 h-3 text-rose-400" />
              <span className="tabular-nums">
                {(session.overlays.viewerBase + Math.floor((session.uptimeSeconds % 30) * 1.5)).toLocaleString()}
              </span>
            </div>
          )}

          {/* Live Studio Clock */}
          {session.overlays.showClock && (
            <div className="bg-neutral-950/80 backdrop-blur-md border border-neutral-800 px-1.5 sm:px-2 py-0.5 rounded text-[10px] sm:text-xs font-mono text-neutral-300 hidden xs:flex items-center gap-1 shadow">
              <Clock className="w-3 h-3 text-neutral-400" />
              <span className="tabular-nums">{currentTimeStr}</span>
            </div>
          )}
        </div>

        {/* OVERLAY 3: Bottom Scrolling News Ticker / Marquee */}
        {session.overlays.showTicker && (
          <div className="absolute bottom-0 inset-x-0 z-20 bg-neutral-950/90 border-t border-rose-950/80 backdrop-blur-sm flex items-center text-xs overflow-hidden h-6 sm:h-7">
            <div className="bg-rose-600 text-white px-2 py-0.5 sm:py-1 font-bold text-[10px] sm:text-[11px] uppercase tracking-wider shrink-0 flex items-center gap-1">
              <Flame className="w-3 h-3" />
              <span>LIVE</span>
            </div>
            <div className="overflow-hidden whitespace-nowrap w-full">
              <div className="animate-marquee font-medium text-neutral-200 tracking-wide text-[11px] sm:text-xs">
                {session.overlays.tickerText || '🔴 সরাসরি সম্প্রচার চলছে • Siam 24/7 Cloud Studio • অফলাইন ব্যাকগ্রাউন্ডে স্ট্রিমিং সচল'}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Broadcast Controller Bar under monitor */}
      <div className="bg-neutral-950 p-2.5 sm:p-3 border-t border-neutral-800 flex flex-wrap items-center justify-between gap-2.5 text-xs">
        {/* Left: Audio levels visualizer & Volume */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-1">
            <span className="text-[10px] font-mono text-neutral-500">VU</span>
            <div className="flex items-end gap-0.5 h-4 w-10 sm:w-12 bg-neutral-900 p-0.5 rounded border border-neutral-800">
              <div className={`w-1 rounded-sm ${isLive && !session.overlays.isMuted ? 'bg-emerald-500 audio-bar-1' : 'bg-neutral-700 h-1'}`} />
              <div className={`w-1 rounded-sm ${isLive && !session.overlays.isMuted ? 'bg-emerald-500 audio-bar-2' : 'bg-neutral-700 h-1'}`} />
              <div className={`w-1 rounded-sm ${isLive && !session.overlays.isMuted ? 'bg-emerald-400 audio-bar-3' : 'bg-neutral-700 h-1'}`} />
              <div className={`w-1 rounded-sm ${isLive && !session.overlays.isMuted ? 'bg-amber-400 audio-bar-4' : 'bg-neutral-700 h-1'}`} />
              <div className={`w-1 rounded-sm ${isLive && !session.overlays.isMuted ? 'bg-rose-500 audio-bar-5' : 'bg-neutral-700 h-1'}`} />
            </div>
          </div>

          {/* Volume Control */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              onClick={onMuteToggle}
              className="text-neutral-400 hover:text-white transition-colors"
              title={session.overlays.isMuted ? 'Unmute' : 'Mute'}
            >
              {session.overlays.isMuted ? (
                <VolumeX className="w-4 h-4 text-rose-400" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </button>
            <input
              type="range"
              min="0"
              max="100"
              value={session.overlays.isMuted ? 0 : session.overlays.audioVolume}
              onChange={(e) => onVolumeChange(Number(e.target.value))}
              className="w-14 sm:w-20 accent-rose-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
            />
            <span className="font-mono text-neutral-400 w-7 sm:w-8 text-[11px] tabular-nums">
              {session.overlays.isMuted ? '0%' : `${session.overlays.audioVolume}%`}
            </span>
          </div>
        </div>

        {/* Center/Right: Current Track & Fullscreen */}
        <div className="flex items-center gap-3 text-neutral-400 font-mono text-[11px] ml-auto">
          <span className="tabular-nums">
            {formatDuration(session.currentVideoTime)} / {formatDuration(currentVideo?.duration || 0)}
          </span>
          <button
            onClick={toggleFullscreen}
            className="p-1 text-neutral-400 hover:text-white transition-colors rounded hover:bg-neutral-800"
            title="Fullscreen Monitor"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}
