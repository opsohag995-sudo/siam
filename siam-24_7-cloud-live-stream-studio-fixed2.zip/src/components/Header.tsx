import React from 'react';
import { Play, Square, Radio, Globe, ShieldCheck, Lock } from 'lucide-react';
import { StreamSession } from '../types/stream';
import { Language, translations } from '../utils/i18n';

interface HeaderProps {
  session: StreamSession;
  activeTab: 'dashboard' | 'streams' | 'media' | 'studio' | 'server' | 'admin';
  setActiveTab: (tab: 'dashboard' | 'streams' | 'media' | 'studio' | 'server' | 'admin') => void;
  lang: Language;
  setLang: (lang: Language) => void;
  onStartStream: () => void;
  onStopStream: () => void;
  isStarting: boolean;
  isAdminAuthenticated: boolean;
  onOpenAdmin: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  session,
  activeTab,
  setActiveTab,
  lang,
  setLang,
  onStartStream,
  onStopStream,
  isStarting,
  isAdminAuthenticated,
  onOpenAdmin,
}) => {
  const t = translations[lang];
  const isLive = session.status === 'live';

  return (
    <header className="sticky top-0 z-40 bg-neutral-950/90 backdrop-blur-md border-b border-neutral-800/80 px-4 lg:px-8 py-3.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Zone 1: Single text element Brand wordmark with live status */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold tracking-tight text-white font-mono flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
              {t.brandName}
            </span>
            <span className="text-xs text-neutral-400 hidden sm:inline">
              · 24/7 Cloud Stream
            </span>
          </div>

          {/* Broadcast status indicator */}
          <div className="flex items-center gap-1.5 text-xs font-mono ml-1 px-2.5 py-1 rounded bg-neutral-900 border border-neutral-800">
            {isLive ? (
              <>
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping inline-block" />
                <span className="text-rose-400 font-semibold tracking-wider">LIVE 24/7</span>
              </>
            ) : (
              <>
                <span className="w-2 h-2 rounded-full bg-neutral-500 inline-block" />
                <span className="text-neutral-400 font-medium tracking-wider">STANDBY</span>
              </>
            )}
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 text-sm font-medium">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'dashboard'
                ? 'bg-neutral-800 text-white font-semibold'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            {t.tabDashboard}
          </button>
          <button
            onClick={() => setActiveTab('streams')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'streams'
                ? 'bg-neutral-800 text-white font-semibold'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            {t.tabStreams}
          </button>
          <button
            onClick={() => setActiveTab('media')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'media'
                ? 'bg-neutral-800 text-white font-semibold'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            {t.tabMedia}
          </button>
          <button
            onClick={() => setActiveTab('studio')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'studio'
                ? 'bg-neutral-800 text-white font-semibold'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            {t.tabStudio}
          </button>
          <button
            onClick={() => setActiveTab('server')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'server'
                ? 'bg-neutral-800 text-white font-semibold'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            {t.tabServer}
          </button>
          <button
            onClick={onOpenAdmin}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 font-bold ${
              activeTab === 'admin'
                ? 'bg-rose-600 text-white'
                : 'text-amber-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-current" />
            <span>{lang === 'bn' ? 'অ্যাডমিন প্যানেল' : 'Admin Panel'}</span>
          </button>
        </nav>

        {/* Zone 3: Language toggle, Admin Mobile Button, & Primary Action */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Mobile & Desktop Quick Admin Button */}
          <button
            onClick={onOpenAdmin}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-mono font-bold transition-all border ${
              activeTab === 'admin'
                ? 'bg-rose-600 text-white border-rose-500 shadow-md shadow-rose-950/50'
                : isAdminAuthenticated
                ? 'bg-emerald-950/70 text-emerald-300 border-emerald-600/60 hover:bg-emerald-900/80'
                : 'bg-amber-950/60 text-amber-300 border-amber-600/50 hover:bg-amber-900/80'
            }`}
            title={lang === 'bn' ? 'অ্যাডমিন প্যানেল' : 'Admin Panel'}
          >
            <Lock className="w-3.5 h-3.5 text-current" />
            <span className="hidden xs:inline">{lang === 'bn' ? 'অ্যাডমিন' : 'Admin'}</span>
          </button>

          {/* Language Switcher */}
          <div className="flex items-center bg-neutral-900 border border-neutral-800 rounded-md p-0.5 text-xs font-medium">
            <button
              onClick={() => setLang('bn')}
              className={`px-2 py-1 rounded transition-colors ${
                lang === 'bn' ? 'bg-neutral-800 text-white font-semibold' : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              বাংলা
            </button>
            <button
              onClick={() => setLang('en')}
              className={`px-2 py-1 rounded transition-colors ${
                lang === 'en' ? 'bg-neutral-800 text-white font-semibold' : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              EN
            </button>
          </div>

          {/* Master Live Control Button */}
          {isLive ? (
            <button
              onClick={onStopStream}
              className="flex items-center gap-2 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-rose-300 hover:text-rose-200 border border-rose-900/60 rounded-md text-xs font-semibold tracking-wide transition-all shadow-sm active:scale-95"
            >
              <Square className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
              <span className="hidden sm:inline">{t.stopLiveStream}</span>
            </button>
          ) : (
            <button
              onClick={onStartStream}
              disabled={isStarting}
              className="flex items-center gap-2 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-md text-xs font-semibold tracking-wide transition-all shadow-md shadow-rose-950/50 hover:shadow-rose-900/60 active:scale-95 disabled:opacity-50"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span className="hidden sm:inline">{isStarting ? t.statusStarting : t.startLiveStream}</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
