import React, { useState } from 'react';
import { CheckCircle2, ChevronDown, ChevronUp, CloudLightning, Laptop, Radio, Server, ShieldCheck, X } from 'lucide-react';
import { Language, translations } from '../utils/i18n';

interface OfflineEducationBannerProps {
  lang: Language;
}

export const OfflineEducationBanner: React.FC<OfflineEducationBannerProps> = ({ lang }) => {
  const t = translations[lang];
  const [isOpen, setIsOpen] = useState(true);

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="w-full text-left py-2 px-3 bg-neutral-900/60 border border-neutral-800 rounded-md text-xs text-neutral-400 hover:text-neutral-200 transition-colors flex items-center justify-between"
      >
        <span className="flex items-center gap-2">
          <CloudLightning className="w-3.5 h-3.5 text-rose-400" />
          <span>{t.howOfflineWorks}</span>
        </span>
        <ChevronDown className="w-3.5 h-3.5 text-neutral-500" />
      </button>
    );
  }

  return (
    <div className="bg-gradient-to-r from-neutral-900 via-neutral-900 to-rose-950/20 border border-neutral-800 rounded-lg p-4 relative shadow-sm">
      <button
        onClick={() => setIsOpen(false)}
        className="absolute top-3 right-3 text-neutral-500 hover:text-neutral-300 p-1"
        aria-label="Collapse banner"
      >
        <ChevronUp className="w-4 h-4" />
      </button>

      <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
        <div className="p-2.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 shrink-0">
          <CloudLightning className="w-6 h-6" />
        </div>

        <div className="flex-1 space-y-1">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-white">
              {lang === 'bn'
                ? '✅ হ্যাঁ! ভিডিও রান করে আপনি অফলাইনে গেলেও স্ট্রিম ২৪/৭ সচল থাকবে'
                : '✅ Yes! Live stream runs 24/7 uninterrupted even when you go offline'}
            </h3>
            <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
              Server-Side Daemon
            </span>
          </div>

          <p className="text-xs text-neutral-400 leading-relaxed max-w-3xl">
            {t.howOfflineDesc}
          </p>

          {/* Step illustration */}
          <div className="pt-2 grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] font-mono">
            <div className="flex items-center gap-1.5 text-neutral-300 bg-neutral-950/60 p-1.5 rounded border border-neutral-800/80">
              <span className="w-4 h-4 rounded-full bg-neutral-800 text-rose-400 flex items-center justify-center font-bold text-[10px]">1</span>
              <span>ভিডিও প্লেলিস্ট ও RTMP সেট করুন</span>
            </div>
            <div className="flex items-center gap-1.5 text-neutral-300 bg-neutral-950/60 p-1.5 rounded border border-neutral-800/80">
              <span className="w-4 h-4 rounded-full bg-neutral-800 text-rose-400 flex items-center justify-center font-bold text-[10px]">2</span>
              <span>"লাইভ শুরু করুন" বাটনে চাপ দিন</span>
            </div>
            <div className="flex items-center gap-1.5 text-emerald-300 bg-emerald-950/20 p-1.5 rounded border border-emerald-800/40">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>ব্রাউজার বন্ধ করলেও ২৪/৭ চলবে!</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
