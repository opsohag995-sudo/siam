/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Radio,
  Play,
  Square,
  AlertCircle,
  Film,
  Sliders,
  Server,
  Layers,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Zap,
  HelpCircle,
  Eye
} from 'lucide-react';
import { StreamSession, StreamTarget, VideoItem, OverlayConfig } from './types/stream';
import { DEFAULT_VIDEOS } from './data/defaultMedia';
import { Language, translations } from './utils/i18n';
import { Header } from './components/Header';
import { BroadcastMonitor } from './components/BroadcastMonitor';
import { TelemetryBar } from './components/TelemetryBar';
import { OfflineEducationBanner } from './components/OfflineEducationBanner';
import { StreamTargetsManager } from './components/StreamTargetsManager';
import { PlaylistManager } from './components/PlaylistManager';
import { OverlaysCustomizer } from './components/OverlaysCustomizer';
import { ServerArchitecture } from './components/ServerArchitecture';
import { QuickStartGuide } from './components/QuickStartGuide';
import { AdminPanel } from './components/AdminPanel';
import { AdminLoginModal } from './components/AdminLoginModal';

// Default initial state while connecting to server
const initialFallbackSession: StreamSession = {
  id: 'siam-stream-primary',
  name: 'Siam 24/7 Lo-Fi & News Broadcast',
  description: 'Automated 24/7 cloud live stream with infinite video looping',
  status: 'idle',
  loopMode: 'infinite_247',
  targets: [
    {
      id: 'target-yt',
      platform: 'youtube',
      label: 'YouTube Live',
      serverUrl: 'rtmp://a.rtmp.youtube.com/live2',
      streamKey: 'siam-yt-live-key-demo',
      enabled: true,
    },
    {
      id: 'target-fb',
      platform: 'facebook',
      label: 'Facebook Live',
      serverUrl: 'rtmps://live-api-s.facebook.com:443/rtmp/',
      streamKey: '',
      enabled: false,
    },
    {
      id: 'target-twitch',
      platform: 'twitch',
      label: 'Twitch',
      serverUrl: 'rtmp://live.twitch.tv/app/',
      streamKey: '',
      enabled: false,
    },
  ],
  playlist: DEFAULT_VIDEOS,
  currentVideoIndex: 0,
  currentVideoTime: 0,
  overlays: {
    showWatermark: true,
    watermarkText: 'SIAM LIVE 24/7',
    showTicker: true,
    tickerText: '🔴 সরাসরি সম্প্রচার চলছে • Siam 24/7 Cloud Studio • অফলাইন থাকলেও স্ট্রিম সচল থাকে • লাইভ সাবস্ক্রাইব করুন',
    showClock: true,
    clockTimezone: 'Asia/Dhaka',
    showViewers: true,
    viewerBase: 1240,
    showSlate: false,
    slateText: 'শীঘ্রই ফিরে আসছি • Be Right Back',
    audioVolume: 85,
    isMuted: false,
  },
  startedAt: null,
  uptimeSeconds: 0,
  fps: 60,
  bitrateKbps: 4500,
  droppedFrames: 0,
  totalBytesSentMb: 0,
  loopCycle: 1,
  serverCpuPercent: 8.5,
  serverMemMb: 142,
  isSlateActive: false,
  logs: [
    {
      timestamp: new Date().toLocaleTimeString(),
      message: 'Siam 24/7 Cloud Streaming Engine ready. Daemon initialized.',
      type: 'info',
    },
  ],
};

export default function App() {
  const [lang, setLang] = useState<Language>('bn');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'streams' | 'media' | 'studio' | 'server' | 'admin'>('dashboard');
  const [session, setSession] = useState<StreamSession>(initialFallbackSession);
  const [isStarting, setIsStarting] = useState(false);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    try {
      return localStorage.getItem('siam_admin_token') !== null;
    } catch (e) {
      return false;
    }
  });
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  const t = translations[lang];

  const handleOpenAdmin = () => {
    if (isAdminAuthenticated) {
      setActiveTab('admin');
    } else {
      setIsLoginModalOpen(true);
    }
  };

  const handleAdminSuccess = () => {
    setIsAdminAuthenticated(true);
    setActiveTab('admin');
  };

  const handleLockAdmin = () => {
    try {
      localStorage.removeItem('siam_admin_token');
    } catch (e) {}
    setIsAdminAuthenticated(false);
    if (activeTab === 'admin') {
      setActiveTab('dashboard');
    }
  };

  // Fetch initial state & poll server every 1.5 seconds to sync state seamlessly
  useEffect(() => {
    let isMounted = true;

    const fetchSession = async () => {
      try {
        const res = await fetch('/api/stream');
        if (res.ok) {
          const data = await res.json();
          if (isMounted) {
            setSession(data);
          }
        }
      } catch (err) {
        // Fallback gracefully to memory state if local dev server middleware is priming
      }
    };

    fetchSession();
    const interval = setInterval(fetchSession, 1500);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  // API Actions
  const handleStartStream = async () => {
    setIsStarting(true);
    try {
      const res = await fetch('/api/stream/start', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setSession(data.session);
      }
    } catch (err) {
      console.error(err);
      // Local fallback
      setSession(prev => ({
        ...prev,
        status: 'live',
        startedAt: Date.now(),
        uptimeSeconds: 0,
        logs: [
          {
            timestamp: new Date().toLocaleTimeString(),
            message: '🚀 [24/7 DAEMON] Siam background live streaming server started!',
            type: 'success',
          },
          ...prev.logs,
        ],
      }));
    } finally {
      setIsStarting(false);
    }
  };

  const handleStopStream = async () => {
    try {
      const res = await fetch('/api/stream/stop', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setSession(data.session);
      }
    } catch (err) {
      console.error(err);
      setSession(prev => ({
        ...prev,
        status: 'idle',
        startedAt: null,
      }));
    }
  };

  const handleToggleSlate = async () => {
    const nextState = !session.isSlateActive;
    try {
      const res = await fetch('/api/stream/slate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isSlateActive: nextState, slateText: session.overlays.slateText }),
      });
      if (res.ok) {
        setSession(prev => ({ ...prev, isSlateActive: nextState }));
      }
    } catch (err) {
      setSession(prev => ({ ...prev, isSlateActive: nextState }));
    }
  };

  const handleVolumeChange = (volume: number) => {
    const updated = { ...session.overlays, audioVolume: volume, isMuted: false };
    setSession(prev => ({ ...prev, overlays: updated }));
    fetch('/api/stream/overlays', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    }).catch(() => {});
  };

  const handleMuteToggle = () => {
    const updated = { ...session.overlays, isMuted: !session.overlays.isMuted };
    setSession(prev => ({ ...prev, overlays: updated }));
    fetch('/api/stream/overlays', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    }).catch(() => {});
  };

  const handleUpdateTargets = (targets: StreamTarget[]) => {
    setSession(prev => ({ ...prev, targets }));
    fetch('/api/stream/targets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ targets }),
    }).catch(() => {});
  };

  const handleUpdatePlaylist = (playlist: VideoItem[]) => {
    setSession(prev => ({ ...prev, playlist }));
    fetch('/api/stream/playlist', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ playlist }),
    }).catch(() => {});
  };

  const handleSelectVideo = (index: number) => {
    setSession(prev => ({ ...prev, currentVideoIndex: index, currentVideoTime: 0 }));
    fetch('/api/stream/select-video', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ index }),
    }).catch(() => {});
  };

  const handleUpdateLoopMode = (mode: 'infinite_247' | 'single') => {
    setSession(prev => ({ ...prev, loopMode: mode }));
    fetch('/api/stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ loopMode: mode }),
    }).catch(() => {});
  };

  const handleUpdateOverlays = (updated: Partial<OverlayConfig>) => {
    const newOverlays = { ...session.overlays, ...updated };
    setSession(prev => ({ ...prev, overlays: newOverlays }));
    fetch('/api/stream/overlays', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newOverlays),
    }).catch(() => {});
  };

  const activeDestinations = session.targets.filter(t => t.enabled);
  const nextVideo = session.playlist[(session.currentVideoIndex + 1) % session.playlist.length];

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans">
      {/* Top Bar Contract (1 Row, 3 Zones) */}
      <Header
        session={session}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        lang={lang}
        setLang={setLang}
        onStartStream={handleStartStream}
        onStopStream={handleStopStream}
        isStarting={isStarting}
        isAdminAuthenticated={isAdminAuthenticated}
        onOpenAdmin={handleOpenAdmin}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-8 space-y-6">
        {/* Quick 3-Step Setup Guide */}
        <QuickStartGuide lang={lang} onGoToTab={setActiveTab} />

        {/* Offline 24/7 Reassurance Banner */}
        <OfflineEducationBanner lang={lang} />

        {/* Top Section: Broadcast Monitor & Studio Control Column */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left: Broadcast Monitor (8 cols) */}
          <div className="lg:col-span-8 space-y-4">
            <BroadcastMonitor
              session={session}
              lang={lang}
              onToggleSlate={handleToggleSlate}
              onVolumeChange={handleVolumeChange}
              onMuteToggle={handleMuteToggle}
            />
          </div>

          {/* Right: Quick Studio Operator Panel (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            {/* Operator Card */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-4">
              <div className="flex items-center gap-3">
                <img
                  src="/src/assets/images/avatar_streamer_1790524788305.jpg"
                  alt="Broadcast Engineer"
                  referrerPolicy="no-referrer"
                  className="w-12 h-12 rounded-lg object-cover border border-neutral-700 shadow"
                />
                <div>
                  <h3 className="text-sm font-bold text-white font-mono flex items-center gap-1.5">
                    <span>SIAM CONTROL</span>
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  </h3>
                  <div className="text-xs text-neutral-400">
                    {lang === 'bn' ? '২৪/৭ অটোমেটেড ব্রডকাস্ট মাস্টার' : '24/7 Automated Cloud Master'}
                  </div>
                </div>
              </div>

              {/* Master Stream Trigger Button */}
              {session.status === 'live' ? (
                <button
                  onClick={handleStopStream}
                  className="w-full py-2.5 px-4 bg-neutral-950 hover:bg-neutral-800 text-rose-400 border border-rose-900/60 rounded-lg text-xs font-bold tracking-wider uppercase transition-all flex items-center justify-center gap-2 shadow-sm"
                >
                  <Square className="w-4 h-4 fill-rose-500 text-rose-500" />
                  <span>{t.stopLiveStream}</span>
                </button>
              ) : (
                <button
                  onClick={handleStartStream}
                  disabled={isStarting}
                  className="w-full py-2.5 px-4 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold tracking-wider uppercase transition-all flex items-center justify-center gap-2 shadow-lg shadow-rose-950/60 disabled:opacity-50"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>{isStarting ? t.statusStarting : t.startLiveStream}</span>
                </button>
              )}

              {/* Direct Open Admin Panel Button */}
              <button
                onClick={handleOpenAdmin}
                className="w-full py-2 px-3 bg-neutral-950 hover:bg-neutral-800 text-amber-300 hover:text-amber-200 border border-amber-500/40 rounded-lg text-xs font-mono font-bold flex items-center justify-center gap-2 transition-all active:scale-95 shadow-sm"
              >
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>{lang === 'bn' ? '🔐 অ্যাডমিন কন্ট্রোল সেন্টার' : '🔐 Admin Control Center'}</span>
              </button>

              {/* Active Relays Status list */}
              <div className="pt-2 border-t border-neutral-800 space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span className="font-semibold text-neutral-300">{t.activeRelays}</span>
                  <span className="font-mono text-emerald-400 font-bold">
                    {activeDestinations.length} Active
                  </span>
                </div>

                <div className="space-y-1.5">
                  {session.targets.map(t => (
                    <div
                      key={t.id}
                      className="flex items-center justify-between px-2.5 py-1.5 rounded bg-neutral-950 border border-neutral-800 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className={`w-2 h-2 rounded-full ${
                            t.enabled && session.status === 'live'
                              ? 'bg-rose-500 animate-pulse'
                              : t.enabled
                              ? 'bg-emerald-500'
                              : 'bg-neutral-600'
                          }`}
                        />
                        <span className="text-neutral-300 font-medium">{t.label}</span>
                      </div>
                      <span className="text-[11px] font-mono text-neutral-500">
                        {t.enabled ? (t.streamKey ? 'Key Configured' : 'Missing Key') : 'Muted'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Next Up Video */}
              {nextVideo && (
                <div className="pt-2 border-t border-neutral-800 text-xs">
                  <div className="text-[11px] text-neutral-400 mb-1">
                    {lang === 'bn' ? 'পরবর্তী ভিডিও (Next In Queue):' : 'Next Video in Loop:'}
                  </div>
                  <div className="p-2 bg-neutral-950 rounded border border-neutral-800 truncate text-neutral-200 font-mono text-[11px]">
                    {nextVideo.title}
                  </div>
                </div>
              )}
            </div>

            {/* Quick Tips */}
            <div className="bg-neutral-900/60 border border-neutral-800/80 rounded-lg p-3 text-xs text-neutral-400 space-y-1.5">
              <div className="font-semibold text-neutral-300 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>{lang === 'bn' ? 'অফলাইন সুবিধার টিপস' : 'Offline 24/7 Tips'}</span>
              </div>
              <p className="text-[11px] leading-relaxed text-neutral-400">
                {lang === 'bn'
                  ? 'একবার স্ট্রিম চালু করলে ক্লাউড সার্ভারে সচল থাকবে। মোবাইল বা কম্পিউটার বন্ধ রাখলেও কোনো সমস্যা নেই।'
                  : 'Once started, the stream process stays alive on the server. You can freely turn off your computer.'}
              </p>
            </div>
          </div>
        </div>

        {/* Telemetry Bar (6 High-Density Live Metric Cards) */}
        <TelemetryBar session={session} lang={lang} />

        {/* Navigation Tabbed Section Content */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-6 shadow-sm">
          {/* Tab Sub-Header */}
          <div className="flex items-center gap-2 mb-6 pb-3 border-b border-neutral-800 text-xs font-mono">
            <span className="text-neutral-500">Workspace /</span>
            <span className="text-white font-semibold uppercase tracking-wider">
              {activeTab === 'dashboard' && (lang === 'bn' ? 'ড্যাশবোর্ড ওভারভিউ' : 'Dashboard Overview')}
              {activeTab === 'streams' && (lang === 'bn' ? 'আরটিএমপি প্ল্যাটফর্ম সংযোগ' : 'RTMP Stream Destinations')}
              {activeTab === 'media' && (lang === 'bn' ? 'ভিডিও প্লেলিস্ট ও লুপ' : 'Video Playlist & Loop Queue')}
              {activeTab === 'studio' && (lang === 'bn' ? 'অন-স্ক্রিন ওভারলে ও গ্রাফিক্স' : 'Studio Overlays & Graphics')}
              {activeTab === 'server' && (lang === 'bn' ? 'সার্ভার ডেমন ও এফএফএমপ্যাগ' : 'Server Daemon & FFmpeg Pipeline')}
              {activeTab === 'admin' && (lang === 'bn' ? 'সুপার অ্যাডমিন মাস্টার কন্ট্রোল প্যানেল' : 'Super Admin Master Control Panel')}
            </span>
          </div>

          {/* Conditional Tab Rendering */}
          {activeTab === 'dashboard' && (
            <div className="space-y-8">
              {/* Destinations Grid Preview */}
              <StreamTargetsManager
                session={session}
                lang={lang}
                onUpdateTargets={handleUpdateTargets}
              />

              {/* Playlist Preview */}
              <PlaylistManager
                session={session}
                lang={lang}
                onUpdatePlaylist={handleUpdatePlaylist}
                onSelectVideo={handleSelectVideo}
                onUpdateLoopMode={handleUpdateLoopMode}
              />
            </div>
          )}

          {activeTab === 'streams' && (
            <StreamTargetsManager
              session={session}
              lang={lang}
              onUpdateTargets={handleUpdateTargets}
            />
          )}

          {activeTab === 'media' && (
            <PlaylistManager
              session={session}
              lang={lang}
              onUpdatePlaylist={handleUpdatePlaylist}
              onSelectVideo={handleSelectVideo}
              onUpdateLoopMode={handleUpdateLoopMode}
            />
          )}

          {activeTab === 'studio' && (
            <OverlaysCustomizer
              overlays={session.overlays}
              lang={lang}
              onUpdateOverlays={handleUpdateOverlays}
            />
          )}

          {activeTab === 'server' && (
            <ServerArchitecture session={session} lang={lang} />
          )}

          {activeTab === 'admin' && (
            <AdminPanel
              session={session}
              lang={lang}
              onStartStream={handleStartStream}
              onStopStream={handleStopStream}
              onUpdateTargets={handleUpdateTargets}
              onUpdatePlaylist={handleUpdatePlaylist}
              onSelectVideo={handleSelectVideo}
              onUpdateLoopMode={handleUpdateLoopMode}
              onUpdateOverlays={handleUpdateOverlays}
              onToggleSlate={handleToggleSlate}
              onLockAdmin={handleLockAdmin}
            />
          )}
        </div>
      </main>

      {/* Admin Login Modal (Passcode: 990) */}
      <AdminLoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onSuccess={handleAdminSuccess}
        lang={lang}
      />

      {/* Footer */}
      <footer className="border-t border-neutral-800/80 bg-neutral-950 py-6 px-4 lg:px-8 mt-12 text-xs text-neutral-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-neutral-300 font-mono">SIAM 24/7</span>
            <span>·</span>
            <span>{lang === 'bn' ? 'সার্ভার-সাইড ক্লাউড লাইভ স্ট্রিমিং ড্যাশবোর্ড' : 'Server-side Cloud Live Streaming Dashboard'}</span>
          </div>

          <div className="flex items-center gap-4 font-mono text-[11px]">
            <span>FFmpeg 6.0 Core</span>
            <span>·</span>
            <span>RTMP / RTMPS Relay</span>
            <span>·</span>
            <span className="text-emerald-500">Daemon Active</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
