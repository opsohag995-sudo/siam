import { VideoItem } from '../types/stream';

export const DEFAULT_VIDEOS: VideoItem[] = [
  {
    id: 'vid-1',
    title: 'Lofi Relaxing Study & Coding Beats 24/7 Loop',
    url: '/media/lofi_stream.mp4',
    duration: 30,
    category: 'music',
    resolution: '1080p 60fps',
  },
  {
    id: 'vid-2',
    title: '24/7 Breaking News & Daily Headlines Studio Loop',
    url: '/media/news_loop.mp4',
    duration: 30,
    category: 'news',
    resolution: '1080p 30fps',
  },
  {
    id: 'vid-3',
    title: 'Cyberpunk Neon Studio Ambient Broadcast',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    duration: 734,
    category: 'gaming',
    resolution: '1080p 30fps',
  }
];

export const RTMP_ENDPOINTS = {
  youtube: {
    label: 'YouTube Live',
    defaultServer: 'rtmps://a.rtmp.youtube.com:443/live2',
    keyPlaceholder: 'xxxx-xxxx-xxxx-xxxx-xxxx',
    guideBn: 'YouTube Studio > Go Live > Stream Settings থেকে Stream URL (RTMPS port 443) ও Stream Key কপি করুন',
    guideEn: 'Copy Stream URL (RTMPS 443) & Stream Key from YouTube Studio > Go Live',
  },
  facebook: {
    label: 'Facebook Live',
    defaultServer: 'rtmps://live-api-s.facebook.com:443/rtmp/',
    keyPlaceholder: 'FB-xxxxxxxxxxxx-0-Abc',
    guideBn: 'Facebook Live Producer থেকে Persistent Stream Key তৈরি করুন (RTMPS 443)',
    guideEn: 'Generate persistent stream key in Facebook Live Producer (RTMPS 443)',
  },
  twitch: {
    label: 'Twitch',
    defaultServer: 'rtmps://live.twitch.tv:443/app/',
    keyPlaceholder: 'live_xxxxxxxxxxxxxxx',
    guideBn: 'Twitch Creator Dashboard > Settings > Stream থেকে Primary Stream Key নিন',
    guideEn: 'Find Primary Stream Key in Twitch Creator Dashboard > Settings > Stream',
  },
  kick: {
    label: 'Kick.com',
    defaultServer: 'rtmps://fa723fc1b171.global-contribute.live-video.net/app/',
    keyPlaceholder: 'sk_us-east-1_xxxxxxxxx',
    guideBn: 'Kick Creator Dashboard > Settings > Stream Key থেকে কপি করুন',
    guideEn: 'Copy from Kick Creator Dashboard > Settings > Stream URL & Key',
  },
  custom: {
    label: 'Custom RTMP / RTMPS Server',
    defaultServer: 'rtmps://your-streaming-server.com:443/live',
    keyPlaceholder: 'secret-stream-key',
    guideBn: 'আপনার নিজস্ব Nginx-RTMP, SRS, Restream অথবা VPS সার্ভারের ঠিকানা দিন (পোর্ট 443 RTMPS সাপোর্ট করে)',
    guideEn: 'Enter your custom Nginx-RTMP, SRS, Restream or private VPS endpoint (supports port 443)',
  },
};

